package com.seninlemutfakta.app

import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity()

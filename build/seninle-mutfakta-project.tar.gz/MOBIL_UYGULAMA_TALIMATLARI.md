# 📱 Seninle Mutfakta - Mobil Uygulama Deploy Talimatları

## ✅ Tamamlanan İşlemler

Capacitor kurulumu ve konfigürasyonu başarıyla tamamlandı:

- ✅ Capacitor core kuruldu
- ✅ Android platformu eklendi
- ✅ iOS platformu eklendi  
- ✅ Production build alındı
- ✅ Konfigürasyon dosyaları hazırlandı

---

## 📂 Dosya Yapısı

```
/app/frontend/
├── android/          # Android native projesi (Android Studio ile açılır)
├── ios/             # iOS native projesi (Xcode ile açılır)
├── build/           # React production build
├── capacitor.config.json  # Capacitor ayarları
└── package.json
```

---

## 🤖 ANDROID UYGULAMASI

### Gereksinimler:
- **Android Studio** (en son versiyon)
- **Java JDK 17+**
- **Android SDK** (API 33+)

### Adım 1: Android Studio'yu Aç
```bash
# Android projesini aç
cd /app/frontend
npx cap open android
```

### Adım 2: Build ve Test
1. Android Studio açıldıktan sonra **Gradle sync** otomatik başlayacak
2. **File → Sync Project with Gradle Files** yapın
3. Emulator veya fiziksel cihaz bağlayın
4. **Run** butonuna basın ▶️

### Adım 3: APK Oluştur (Test için)
1. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. APK: `/app/frontend/android/app/build/outputs/apk/debug/app-debug.apk`
3. Bu APK'yı telefonunuza aktarıp test edebilirsiniz

### Adım 4: Play Store için AAB Oluştur
1. **Build → Generate Signed Bundle / APK**
2. **Android App Bundle** seçin
3. Keystore oluşturun (ilk kez):
   - **Create new keystore**
   - Güvenli bir yerde saklayın! (kaybolursa güncelleme yapamazsınız)
4. AAB dosyası: `/app/frontend/android/app/build/outputs/bundle/release/`

### Adım 5: Play Store'a Yükleme
1. https://play.google.com/console adresine gidin
2. **Create app** yapın
3. Uygulama detaylarını doldurun:
   - Uygulama adı: **Seninle Mutfakta**
   - Kategori: **Yaşam Tarzı** veya **Yemek & İçecek**
4. **Release → Production → Create new release**
5. AAB dosyasını yükleyin
6. İnceleme için gönderin (1-7 gün sürer)

**Maliyet:** Google Play Developer hesabı - $25 (bir kerelik)

---

## 🍎 iOS UYGULAMASI

### Gereksinimler:
- **Mac bilgisayar** (zorunlu)
- **Xcode 15+**
- **CocoaPods** (`sudo gem install cocoapods`)
- **Apple Developer hesabı** ($99/yıl)

### Adım 1: Xcode'u Aç
```bash
# iOS projesini aç
cd /app/frontend
pod install --project-directory=ios/App  # Pod'ları yükle
npx cap open ios
```

### Adım 2: Signing & Capabilities
1. Xcode'da projeyi seçin (sol panelde)
2. **Signing & Capabilities** sekmesine gidin
3. **Team** kısmında Apple Developer hesabınızı seçin
4. **Bundle Identifier**: `com.seninlemutfakta.app` (unique olmalı)

### Adım 3: Simulator'de Test
1. Üst menüden iOS simulator seçin (örn: iPhone 15 Pro)
2. **Run** butonuna basın ▶️
3. Simulator açılacak ve uygulama çalışacak

### Adım 4: Fiziksel Cihazda Test
1. iPhone'unuzu Mac'e bağlayın
2. Xcode'da cihazınızı seçin
3. **Run** yapın
4. İlk kez: iPhone'da **Settings → General → VPN & Device Management** → sertifikayı onaylayın

### Adım 5: App Store için Archive
1. **Product → Archive**
2. Organizer penceresi açılacak
3. **Distribute App** → **App Store Connect**
4. Adımları takip edin

### Adım 6: App Store'a Yükleme
1. https://appstoreconnect.apple.com adresine gidin
2. **My Apps → + → New App**
3. Uygulama bilgilerini doldurun:
   - Ad: **Seninle Mutfakta**
   - Kategori: **Food & Drink** veya **Lifestyle**
4. Screenshots ekleyin (iPhone + iPad için)
5. **Submit for Review**
6. İnceleme: 1-3 gün sürer

**Maliyet:** Apple Developer Program - $99/yıl

---

## 🔄 Güncelleme Yapmak

### 1. Frontend'de değişiklik yaptıktan sonra:
```bash
cd /app/frontend

# Production build al
REACT_APP_BACKEND_URL=https://couple-cooking-1.preview.emergentagent.com yarn build

# Native projelere kopyala
npx cap sync
```

### 2. Android'i güncelle:
```bash
npx cap open android
# Android Studio'da build alıp yeni versiyon yükle
```

### 3. iOS'u güncelle:
```bash
npx cap open ios
# Xcode'da build alıp yeni versiyon yükle
```

---

## 🎨 Uygulama İkonları ve Splash Screen

### İkon Gereksinimleri:
- **Android:** 1024×1024 px (PNG)
- **iOS:** 1024×1024 px (PNG, şeffaf olmayan arka plan)

### İkon Ekleme:

#### Android:
1. https://icon.kitchen gibi bir araç kullanın
2. İkon setini oluşturun
3. `/app/frontend/android/app/src/main/res/` klasörüne kopyalayın

#### iOS:
1. 1024×1024 px ikon hazırlayın
2. `/app/frontend/ios/App/App/Assets.xcassets/AppIcon.appiconset/` içine ekleyin

### Splash Screen:
```bash
# Capacitor splash screen plugin
yarn add @capacitor/splash-screen

# capacitor.config.json'a ekle:
{
  "plugins": {
    "SplashScreen": {
      "launchShowDuration": 2000,
      "backgroundColor": "#FFE5D9",
      "showSpinner": false
    }
  }
}
```

---

## 🔧 Sorun Giderme

### Android Build Hataları:
```bash
# Gradle cache temizle
cd /app/frontend/android
./gradlew clean

# Tekrar build al
./gradlew assembleDebug
```

### iOS Build Hataları:
```bash
# Pod'ları temizle ve yeniden yükle
cd /app/frontend/ios/App
pod deintegrate
pod install

# Derived data temizle
rm -rf ~/Library/Developer/Xcode/DerivedData
```

### Web Assets Güncellenmedi:
```bash
cd /app/frontend
rm -rf build
yarn build
npx cap sync
```

---

## 📊 Store Bilgileri

### Uygulama Açıklaması (Türkçe):
```
Eşinizle birlikte dünya mutfaklarını keşfedin! 

"Seninle Mutfakta", çiftlerin birlikte yemek yapmasını eğlenceli bir deneyime dönüştürüyor. 

✨ Özellikler:
• 50+ farklı ülke tarifini keşfedin
• Eş zamanlı tarif takibi
• Ülke bazlı rozet ve pasaport sistemi
• Yaptığınız yemekleri sosyal alanda paylaşın
• Her adımda animasyonlu rehberlik
• Kadın ve erkek profili ayrı takip

🌍 Ülkeler:
• Fransa 🇫🇷
• İtalya 🇮🇹
• Türkiye 🇹🇷
• Japonya 🇯🇵
• Meksika 🇲🇽

Eşinizle mutfakta geçireceğiniz keyifli anlar için hemen indirin!
```

### Keywords (Türkçe):
```
yemek, tarif, çift, mutfak, pişirme, dünya mutfağı, eşli yemek, romantik, birlikte, cooking
```

### App Kategorisi:
- **Primary:** Food & Drink
- **Secondary:** Lifestyle

### Screenshots (Gerekli):
- iPhone: 6.7" (1290 x 2796 px) - en az 3 screenshot
- iPad: 12.9" (2048 x 2732 px) - en az 3 screenshot
- Android: 1080 x 1920 px - en az 2 screenshot

---

## 📝 Önemli Notlar

1. **Developer Hesapları:**
   - Google Play: $25 (bir kerelik)
   - Apple App Store: $99 (yıllık)

2. **İnceleme Süreleri:**
   - Android: 1-7 gün
   - iOS: 1-3 gün

3. **Güncelleme Politikası:**
   - Her güncelleme yeni inceleme gerektir
   - Versiyon numarasını artırmayı unutmayın

4. **Backend URL:**
   - Şu an: `https://couple-cooking-1.preview.emergentagent.com`
   - Production'a geçtiğinizde bu URL'i güncelleyin

5. **Test:**
   - Her iki platformda da test edin
   - Farklı ekran boyutlarında test edin
   - Backend API'nin çalıştığından emin olun

---

## 🚀 Hızlı Başlangıç

### Sadece test için APK almak istiyorsanız:
```bash
cd /app/frontend
REACT_APP_BACKEND_URL=https://couple-cooking-1.preview.emergentagent.com yarn build
npx cap sync
npx cap open android
# Android Studio'da Run → Build APK
```

### Store'a yüklemek için:
1. Developer hesaplarını oluşturun
2. Yukarıdaki adımları takip edin
3. İlk yükleme için yardım isterseniz bana yazın!

---

## 📧 Destek

Herhangi bir sorun yaşarsanız:
1. Hata mesajını tam olarak not edin
2. Hangi adımda takıldığınızı belirtin  
3. Screenshot paylaşın
4. Bana ulaşın, yardımcı olurum!

---

**Başarılar! 🎉**

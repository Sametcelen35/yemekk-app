# 📱 APK Nasıl İndirilir ve Test Edilir?

## 🎯 Durum

Capacitor ile mobil uygulama projesi başarıyla oluşturuldu! Ancak APK oluşturmak için **Android SDK** gerekiyor ve bu konsolda mevcut değil.

## ✅ 2 Kolay Seçenek

---

## SEÇENEK 1: Kendi Bilgisayarınızda Build Alın (Önerilen)

### Gereksinimler:
- **Android Studio** (ücretsiz)
- En az 8GB RAM
- 10GB boş disk alanı

### Adımlar:

#### 1. Projeyi İndirin
```bash
# Bu projeyi bilgisayarınıza klonlayın veya indirin
# /app/frontend klasörünü kopyalayın
```

#### 2. Android Studio'yu Kurun
- https://developer.android.com/studio adresinden indirin
- Kurulum sırasında **Android SDK** otomatik yüklenecek
- İlk açılışta "Standard" kurulum seçin

#### 3. Projeyi Açın
1. Android Studio'yu başlatın
2. **Open an Existing Project** seçin
3. `/app/frontend/android` klasörünü seçin
4. Gradle sync otomatik başlayacak (5-10 dk sürebilir)

#### 4. APK Oluşturun
**Test APK (Debug):**
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

APK konumu: `/app/frontend/android/app/build/outputs/apk/debug/app-debug.apk`

**Store APK (Release):**
```
Build → Generate Signed Bundle / APK
→ APK → Create New Keystore
→ Keystore'u güvenli bir yere kaydedin
→ Build
```

#### 5. Telefonunuza Yükleyin
1. APK dosyasını telefonunuza atın (WhatsApp, email, USB)
2. Telefonda **APK'ya tıklayın**
3. "Bilinmeyen kaynaklardan yükleme" izni verin
4. Yükle butonuna basın
5. Uygulama yüklendi! 🎉

---

## SEÇENEK 2: Online Build Servisi Kullanın

### EAS Build (Expo Application Services)

#### Avantajları:
- Bilgisayarınızda Android Studio gerektirmez
- Cloud'da build alır
- Hem Android hem iOS

#### Kurulum:
```bash
cd /app/frontend

# EAS CLI kur
npm install -g eas-cli

# EAS hesabı oluştur (ücretsiz)
eas login

# Projeyi yapılandır
eas build:configure

# Android APK build'i başlat
eas build --platform android --profile preview
```

Build tamamlandığında size bir **download linki** verilecek!

**Maliyet:**
- Ücretsiz plan: Ayda 30 build
- Pro plan: $29/ay (sınırsız)

---

## 🚀 Hızlı Test (Alternatif)

Eğer sadece test etmek istiyorsanız:

### 1. Expo Go ile Test
```bash
cd /app/frontend
npm install -g expo-cli
expo start
```

Telefonunuzda **Expo Go** uygulamasını indirin ve QR kodu taratın.

⚠️ **Not:** Bu tam native değil, bazı özellikler çalışmayabilir.

---

## 📋 APK Test Kontrolü

APK'yı telefonunuza yükledikten sonra kontrol edin:

✅ Uygulama açılıyor mu?
✅ Giriş/Kayıt çalışıyor mu?
✅ Ülkeler görünüyor mu?
✅ Tarif listesi yükleniyor mu?
✅ Resim yükleme çalışıyor mu?
✅ Sosyal alan çalışıyor mu?

---

## 🐛 Sorun Giderme

### "Uygulama açılmıyor"
- Backend'in çalıştığından emin olun
- İnternet bağlantınızı kontrol edin
- Logları kontrol edin: `adb logcat`

### "SDK bulunamadı"
- Android Studio'da **SDK Manager** açın
- **Android 13 (API 33)** yükleyin
- **SDK Build-Tools** yükleyin

### "Gradle sync hatası"
```bash
cd /app/frontend/android
./gradlew clean
./gradlew build
```

---

## 💡 Öneriler

1. **İlk test için:** Android Studio kullanın (en kolay)
2. **Sürekli build için:** EAS Build kullanın (otomatik)
3. **Hızlı prototype için:** Expo Go kullanın

---

## 📞 Yardım

Takıldığınız yer olursa:
1. Hata mesajını kopyalayın
2. Screenshot alın
3. Bana sorun, yardımcı olurum!

---

**Not:** `/app/MOBIL_UYGULAMA_TALIMATLARI.md` dosyasında daha detaylı bilgiler var!

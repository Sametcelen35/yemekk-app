from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
import base64

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24 * 7  # 7 days

security = HTTPBearer()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Seninle Mutfakta API", "status": "running"}

# ===== MODELS =====

class UserRegister(BaseModel):
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class GenderSelect(BaseModel):
    gender: str  # 'female' or 'male'
    name: str  # İsim cinsiyet seçiminden sonra alınacak

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    name: str
    gender: Optional[str] = None  # 'female' or 'male'
    profile_photo: Optional[str] = None  # URL or data URL
    avatar_id: Optional[int] = None  # Avatar seçimi için
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CoupleProfile(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    partner_id: Optional[str] = None  # Partner's user ID
    female_name: str
    male_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CoupleProfileCreate(BaseModel):
    female_name: str
    male_name: str
    partner_email: Optional[str] = None  # Optional: to link with partner

class Country(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    flag: str
    is_unlocked: bool
    recipes_count: int

class Recipe(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    country_id: str
    title: str
    description: str
    image_url: str
    difficulty: str
    duration_minutes: int
    steps_count: int

class RecipeStep(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    recipe_id: str
    step_number: int
    title: str
    description: str
    animation_type: str  # 'chop', 'stir', 'pour', 'mix', 'cook'
    duration_seconds: int

class Progress(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    recipe_id: str
    completed: bool
    current_step: int = 0  # Track current step for real-time sync
    completed_at: Optional[datetime] = None
    badges_earned: List[str] = []

class ProgressUpdate(BaseModel):
    recipe_id: str
    completed: bool
    current_step: Optional[int] = None

class Post(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    recipe_id: Optional[str] = None  # Optional artık
    post_type: str = 'recipe_share'  # 'recipe_share', 'question', 'tip', 'general'
    image_url: str
    caption: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    likes_count: int = 0
    comments_count: int = 0

class PostCreate(BaseModel):
    recipe_id: Optional[str] = None
    post_type: str = 'recipe_share'
    image_url: str
    caption: str

class Comment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    post_id: str
    user_id: str
    user_name: str
    text: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CommentCreate(BaseModel):
    text: str

class Like(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    post_id: str
    user_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ===== AUTH HELPERS =====

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get('user_id')
        if not user_id:
            raise HTTPException(status_code=401, detail='Invalid token')
        
        user = await db.users.find_one({'id': user_id}, {'_id': 0, 'password': 0})
        if not user:
            raise HTTPException(status_code=401, detail='User not found')
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail='Token expired')
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail='Invalid token')

# ===== AUTH ROUTES =====

@api_router.post("/auth/register")
async def register(user_data: UserRegister):
    # Check if user exists
    existing = await db.users.find_one({'email': user_data.email})
    if existing:
        raise HTTPException(status_code=400, detail='Email already registered')
    
    # Create user without name (will be added after gender selection)
    user = User(
        email=user_data.email,
        name="User"  # Temporary name
    )
    user_dict = user.model_dump()
    user_dict['password'] = hash_password(user_data.password)
    user_dict['created_at'] = user_dict['created_at'].isoformat()
    
    await db.users.insert_one(user_dict)
    
    token = create_token(user.id)
    return {'token': token, 'user': user.model_dump()}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    user = await db.users.find_one({'email': credentials.email})
    if not user or not verify_password(credentials.password, user['password']):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    
    token = create_token(user['id'])
    user_data = {k: v for k, v in user.items() if k not in ['_id', 'password']}
    return {'token': token, 'user': user_data}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return current_user

@api_router.post("/auth/select-gender")
async def select_gender(data: GenderSelect, current_user: dict = Depends(get_current_user)):
    await db.users.update_one(
        {'id': current_user['id']},
        {'$set': {'gender': data.gender, 'name': data.name}}
    )
    user = await db.users.find_one({'id': current_user['id']}, {'_id': 0, 'password': 0})
    return user

@api_router.post("/auth/update-profile")
async def update_profile(data: dict, current_user: dict = Depends(get_current_user)):
    """Update user profile (photo, avatar, name)"""
    update_data = {}
    if 'profile_photo' in data:
        update_data['profile_photo'] = data['profile_photo']
    if 'avatar_id' in data:
        update_data['avatar_id'] = data['avatar_id']
    if 'name' in data:
        update_data['name'] = data['name']
    
    if update_data:
        await db.users.update_one(
            {'id': current_user['id']},
            {'$set': update_data}
        )
    
    user = await db.users.find_one({'id': current_user['id']}, {'_id': 0, 'password': 0})
    return user

@api_router.get("/avatars")
async def get_avatars():
    """Get available avatars"""
    avatars = {
        'male': [
            {'id': 1, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&gender=male'},
            {'id': 2, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka&gender=male'},
            {'id': 3, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=John&gender=male'},
            {'id': 4, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Max&gender=male'},
        ],
        'female': [
            {'id': 5, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jasmine&gender=female'},
            {'id': 6, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sophie&gender=female'},
            {'id': 7, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma&gender=female'},
            {'id': 8, 'url': 'https://api.dicebear.com/7.x/avataaars/svg?seed=Luna&gender=female'},
        ]
    }
    return avatars

# ===== COUPLE PROFILE ROUTES =====

@api_router.post("/couples", response_model=CoupleProfile)
async def create_couple(data: CoupleProfileCreate, current_user: dict = Depends(get_current_user)):
    # Check if couple already exists
    existing = await db.couples.find_one({'user_id': current_user['id']})
    if existing:
        raise HTTPException(status_code=400, detail='Couple profile already exists')
    
    couple = CoupleProfile(
        user_id=current_user['id'],
        female_name=data.female_name,
        male_name=data.male_name
    )
    couple_dict = couple.model_dump()
    couple_dict['created_at'] = couple_dict['created_at'].isoformat()
    
    await db.couples.insert_one(couple_dict)
    return couple

@api_router.get("/couples/me", response_model=CoupleProfile)
async def get_my_couple(current_user: dict = Depends(get_current_user)):
    couple = await db.couples.find_one({'user_id': current_user['id']}, {'_id': 0})
    if not couple:
        raise HTTPException(status_code=404, detail='Couple profile not found')
    return couple

# ===== COUNTRIES ROUTES =====

@api_router.get("/countries", response_model=List[Country])
async def get_countries(current_user: dict = Depends(get_current_user)):
    countries = await db.countries.find({}, {'_id': 0}).to_list(100)
    if not countries:
        # Initialize countries if empty
        countries_data = [
            {'id': 'france', 'name': 'France', 'flag': '🇫🇷', 'is_unlocked': True, 'recipes_count': 10},
            {'id': 'italy', 'name': 'Italy', 'flag': '🇮🇹', 'is_unlocked': True, 'recipes_count': 10},
            {'id': 'turkey', 'name': 'Turkey', 'flag': '🇹🇷', 'is_unlocked': False, 'recipes_count': 10},
            {'id': 'japan', 'name': 'Japan', 'flag': '🇯🇵', 'is_unlocked': False, 'recipes_count': 10},
            {'id': 'mexico', 'name': 'Mexico', 'flag': '🇲🇽', 'is_unlocked': False, 'recipes_count': 10},
        ]
        await db.countries.insert_many(countries_data)
        countries = countries_data
    return countries

# ===== RECIPES ROUTES =====

@api_router.get("/recipes", response_model=List[Recipe])
async def get_recipes(country_id: Optional[str] = None, current_user: dict = Depends(get_current_user)):
    query = {'country_id': country_id} if country_id else {}
    recipes = await db.recipes.find(query, {'_id': 0}).to_list(100)
    
    # Initialize recipes if empty
    if not recipes and not country_id:
        await initialize_recipes()
        recipes = await db.recipes.find(query, {'_id': 0}).to_list(100)
    
    return recipes

@api_router.get("/recipes/{recipe_id}", response_model=Recipe)
async def get_recipe(recipe_id: str, current_user: dict = Depends(get_current_user)):
    recipe = await db.recipes.find_one({'id': recipe_id}, {'_id': 0})
    if not recipe:
        raise HTTPException(status_code=404, detail='Recipe not found')
    return recipe

@api_router.get("/recipes/{recipe_id}/steps", response_model=List[RecipeStep])
async def get_recipe_steps(recipe_id: str, current_user: dict = Depends(get_current_user)):
    steps = await db.recipe_steps.find({'recipe_id': recipe_id}, {'_id': 0}).sort('step_number', 1).to_list(100)
    return steps

# ===== PROGRESS ROUTES =====

@api_router.get("/progress", response_model=List[Progress])
async def get_progress(current_user: dict = Depends(get_current_user)):
    progress = await db.progress.find({'user_id': current_user['id']}, {'_id': 0}).to_list(1000)
    return progress

@api_router.get("/progress/country-badges/{country_id}")
async def get_country_badges(country_id: str, current_user: dict = Depends(get_current_user)):
    """Get user's badge for a specific country"""
    # Get completed recipes for this country
    recipes = await db.recipes.find({'country_id': country_id}, {'_id': 0, 'id': 1}).to_list(100)
    recipe_ids = [r['id'] for r in recipes]
    
    completed = await db.progress.count_documents({
        'user_id': current_user['id'],
        'recipe_id': {'$in': recipe_ids},
        'completed': True
    })
    
    # Determine badge level
    badge_info = get_country_badge_info(country_id, completed, len(recipe_ids))
    
    return {
        'country_id': country_id,
        'completed_recipes': completed,
        'total_recipes': len(recipe_ids),
        'badge': badge_info
    }

@api_router.get("/progress/passports")
async def get_all_passports(current_user: dict = Depends(get_current_user)):
    """Get all earned passports"""
    countries = ['france', 'italy', 'turkey', 'japan', 'mexico']
    passports = []
    
    for country_id in countries:
        recipes = await db.recipes.find({'country_id': country_id}, {'_id': 0, 'id': 1}).to_list(100)
        recipe_ids = [r['id'] for r in recipes]
        
        completed = await db.progress.count_documents({
            'user_id': current_user['id'],
            'recipe_id': {'$in': recipe_ids},
            'completed': True
        })
        
        total = len(recipe_ids)
        if completed >= total and total > 0:
            badge_info = get_country_badge_info(country_id, completed, total)
            passports.append({
                'country_id': country_id,
                'badge': badge_info['current'],
                'earned_at': None  # Could track this with a timestamp
            })
    
    return passports

def get_country_badge_info(country_id: str, completed: int, total: int):
    """Get badge information based on country and completion"""
    badges = {
        'france': [
            {'level': 0, 'name': 'Yeni Şef', 'icon': '🍳', 'emoji': '🥐', 'min': 0, 'title': 'Yeni Şef'},
            {'level': 1, 'name': 'Fransız Aşçısı', 'icon': '👨‍🍳', 'emoji': '🥐', 'min': 1, 'title': 'Çırak Şef'},
            {'level': 2, 'name': 'Paris Şefi', 'icon': '🗼', 'emoji': '🥐', 'min': 3, 'title': 'Paris Gourmet'},
            {'level': 3, 'name': 'Gurme Şef', 'icon': '⭐', 'emoji': '🥐', 'min': 6, 'title': 'Gurme Şef'},
            {'level': 4, 'name': 'Pasaport 🇫🇷', 'icon': '🛂', 'emoji': '🇫🇷', 'min': 10, 'title': 'France Passport'},
        ],
        'italy': [
            {'level': 0, 'name': 'Yeni Şef', 'icon': '🍳', 'emoji': '🍕', 'min': 0, 'title': 'Yeni Şef'},
            {'level': 1, 'name': 'İtalyan Aşçısı', 'icon': '👨‍🍳', 'emoji': '🍕', 'min': 1, 'title': 'Çırak Şef'},
            {'level': 2, 'name': 'Roma Şefi', 'icon': '🏛️', 'emoji': '🍕', 'min': 3, 'title': 'Pizza Master'},
            {'level': 3, 'name': 'Gurme Şef', 'icon': '⭐', 'emoji': '🍕', 'min': 6, 'title': 'Gurme Şef'},
            {'level': 4, 'name': 'Pasaport 🇮🇹', 'icon': '🛂', 'emoji': '🇮🇹', 'min': 10, 'title': 'Italy Passport'},
        ],
        'turkey': [
            {'level': 0, 'name': 'Yeni Şef', 'icon': '🍳', 'emoji': '🧿', 'min': 0, 'title': 'Yeni Şef'},
            {'level': 1, 'name': 'Türk Aşçısı', 'icon': '👨‍🍳', 'emoji': '🧿', 'min': 1, 'title': 'Çırak Aşçı'},
            {'level': 2, 'name': 'İstanbul Aşçısı', 'icon': '🕌', 'emoji': '🧿', 'min': 3, 'title': 'Anadolu Chef'},
            {'level': 3, 'name': 'Usta Aşçı', 'icon': '⭐', 'emoji': '🧿', 'min': 6, 'title': 'Usta Aşçı'},
            {'level': 4, 'name': 'Pasaport 🇹🇷', 'icon': '🛂', 'emoji': '🇹🇷', 'min': 10, 'title': 'Turkey Passport'},
        ],
        'japan': [
            {'level': 0, 'name': 'Yeni Şef', 'icon': '🍳', 'emoji': '🍣', 'min': 0, 'title': 'Yeni Şef'},
            {'level': 1, 'name': 'Japon Aşçısı', 'icon': '👨‍🍳', 'emoji': '🍣', 'min': 1, 'title': 'Çırak Şef'},
            {'level': 2, 'name': 'Tokyo Şefi', 'icon': '🗾', 'emoji': '🍣', 'min': 3, 'title': 'Sushi Samurai'},
            {'level': 3, 'name': 'Gurme Şef', 'icon': '⭐', 'emoji': '🍣', 'min': 6, 'title': 'Gurme Şef'},
            {'level': 4, 'name': 'Pasaport 🇯🇵', 'icon': '🛂', 'emoji': '🇯🇵', 'min': 10, 'title': 'Japan Passport'},
        ],
        'mexico': [
            {'level': 0, 'name': 'Yeni Şef', 'icon': '🍳', 'emoji': '🌮', 'min': 0, 'title': 'Yeni Şef'},
            {'level': 1, 'name': 'Meksika Aşçısı', 'icon': '👨‍🍳', 'emoji': '🌮', 'min': 1, 'title': 'Çırak Şef'},
            {'level': 2, 'name': 'Mexico City Şefi', 'icon': '🌮', 'emoji': '🌮', 'min': 3, 'title': 'Taco Maestro'},
            {'level': 3, 'name': 'Gurme Şef', 'icon': '⭐', 'emoji': '🌮', 'min': 6, 'title': 'Gurme Şef'},
            {'level': 4, 'name': 'Pasaport 🇲🇽', 'icon': '🛂', 'emoji': '🇲🇽', 'min': 10, 'title': 'Mexico Passport'},
        ],
    }
    
    country_badges = badges.get(country_id, badges['france'])
    
    # Find current badge
    current_badge = country_badges[0]
    for badge in country_badges:
        if completed >= badge['min']:
            current_badge = badge
    
    # Find next badge
    next_badge = None
    for badge in country_badges:
        if badge['level'] > current_badge['level']:
            next_badge = badge
            break
    
    return {
        'current': current_badge,
        'next': next_badge,
        'is_passport': completed >= total and total > 0,
        'progress_percentage': (completed / total * 100) if total > 0 else 0
    }
async def get_partner_progress(recipe_id: str, current_user: dict = Depends(get_current_user)):
    """Get partner's progress for a specific recipe"""
    # Find couple
    couple = await db.couples.find_one({'user_id': current_user['id']})
    if not couple or not couple.get('partner_id'):
        return {'current_step': 0, 'completed': False}
    
    # Get partner's progress
    partner_progress = await db.progress.find_one({
        'user_id': couple['partner_id'],
        'recipe_id': recipe_id
    }, {'_id': 0})
    
    if partner_progress:
        return partner_progress
    return {'current_step': 0, 'completed': False}

@api_router.post("/progress", response_model=Progress)
async def update_progress(data: ProgressUpdate, current_user: dict = Depends(get_current_user)):
    existing = await db.progress.find_one({'user_id': current_user['id'], 'recipe_id': data.recipe_id})
    
    if existing:
        # Update existing
        update_data = {'completed': data.completed}
        if data.completed:
            update_data['completed_at'] = datetime.now(timezone.utc).isoformat()
        if data.current_step is not None:
            update_data['current_step'] = data.current_step
        await db.progress.update_one(
            {'user_id': current_user['id'], 'recipe_id': data.recipe_id},
            {'$set': update_data}
        )
        updated = await db.progress.find_one({'user_id': current_user['id'], 'recipe_id': data.recipe_id}, {'_id': 0})
        return updated
    else:
        # Create new
        progress = Progress(
            user_id=current_user['id'],
            recipe_id=data.recipe_id,
            completed=data.completed,
            current_step=data.current_step if data.current_step is not None else 0,
            completed_at=datetime.now(timezone.utc) if data.completed else None
        )
        progress_dict = progress.model_dump()
        if progress_dict['completed_at']:
            progress_dict['completed_at'] = progress_dict['completed_at'].isoformat()
        await db.progress.insert_one(progress_dict)
        return progress

# ===== SOCIAL ROUTES =====

@api_router.get("/posts", response_model=List[Post])
async def get_posts(current_user: dict = Depends(get_current_user)):
    posts = await db.posts.find({}, {'_id': 0}).sort('created_at', -1).to_list(100)
    for post in posts:
        if isinstance(post['created_at'], str):
            post['created_at'] = datetime.fromisoformat(post['created_at'])
    return posts

@api_router.post("/posts", response_model=Post)
async def create_post(data: PostCreate, current_user: dict = Depends(get_current_user)):
    post = Post(
        user_id=current_user['id'],
        recipe_id=data.recipe_id,
        post_type=data.post_type,
        image_url=data.image_url,
        caption=data.caption
    )
    post_dict = post.model_dump()
    post_dict['created_at'] = post_dict['created_at'].isoformat()
    await db.posts.insert_one(post_dict)
    return post

@api_router.get("/posts/{post_id}/comments", response_model=List[Comment])
async def get_comments(post_id: str, current_user: dict = Depends(get_current_user)):
    comments = await db.comments.find({'post_id': post_id}, {'_id': 0}).sort('created_at', 1).to_list(100)
    for comment in comments:
        if isinstance(comment['created_at'], str):
            comment['created_at'] = datetime.fromisoformat(comment['created_at'])
    return comments

@api_router.post("/posts/{post_id}/comments", response_model=Comment)
async def create_comment(post_id: str, data: CommentCreate, current_user: dict = Depends(get_current_user)):
    comment = Comment(
        post_id=post_id,
        user_id=current_user['id'],
        user_name=current_user['name'],
        text=data.text
    )
    comment_dict = comment.model_dump()
    comment_dict['created_at'] = comment_dict['created_at'].isoformat()
    await db.comments.insert_one(comment_dict)
    
    # Increment comments count
    await db.posts.update_one({'id': post_id}, {'$inc': {'comments_count': 1}})
    
    return comment

@api_router.post("/posts/{post_id}/like")
async def toggle_like(post_id: str, current_user: dict = Depends(get_current_user)):
    existing_like = await db.likes.find_one({'post_id': post_id, 'user_id': current_user['id']})
    
    if existing_like:
        # Unlike
        await db.likes.delete_one({'post_id': post_id, 'user_id': current_user['id']})
        await db.posts.update_one({'id': post_id}, {'$inc': {'likes_count': -1}})
        return {'liked': False}
    else:
        # Like
        like = Like(post_id=post_id, user_id=current_user['id'])
        like_dict = like.model_dump()
        like_dict['created_at'] = like_dict['created_at'].isoformat()
        await db.likes.insert_one(like_dict)
        await db.posts.update_one({'id': post_id}, {'$inc': {'likes_count': 1}})
        return {'liked': True}

@api_router.get("/posts/{post_id}/is-liked")
async def check_like(post_id: str, current_user: dict = Depends(get_current_user)):
    like = await db.likes.find_one({'post_id': post_id, 'user_id': current_user['id']})
    return {'liked': like is not None}

@api_router.post("/upload-image")
async def upload_image(file: UploadFile = File(...), current_user: dict = Depends(get_current_user)):
    """Upload image and return base64 data URL"""
    try:
        contents = await file.read()
        # Convert to base64
        base64_image = base64.b64encode(contents).decode('utf-8')
        # Determine mime type
        mime_type = file.content_type or 'image/jpeg'
        # Return data URL
        data_url = f"data:{mime_type};base64,{base64_image}"
        return {'image_url': data_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading image: {str(e)}")

# ===== HELPER FUNCTIONS =====

async def initialize_recipes():
    """Initialize sample recipes for France and Italy"""
    recipes_data = [
        # France recipes
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Coq au Vin', 'description': 'Classic French chicken braised in wine', 'image_url': 'https://images.unsplash.com/photo-1621327017866-6fb07e6c96ea', 'difficulty': 'medium', 'duration_minutes': 90, 'steps_count': 8},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Ratatouille', 'description': 'Provençal vegetable stew', 'image_url': 'https://images.unsplash.com/photo-1600663791817-d74f5196ba29', 'difficulty': 'easy', 'duration_minutes': 60, 'steps_count': 6},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Crème Brûlée', 'description': 'Rich custard dessert with caramelized sugar', 'image_url': 'https://images.unsplash.com/photo-1621327017866-6fb07e6c96ea', 'difficulty': 'medium', 'duration_minutes': 45, 'steps_count': 5},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'French Onion Soup', 'description': 'Rich soup with caramelized onions and melted cheese', 'image_url': 'https://images.unsplash.com/photo-1600663791817-d74f5196ba29', 'difficulty': 'easy', 'duration_minutes': 75, 'steps_count': 7},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Beef Bourguignon', 'description': 'Tender beef stew in red wine', 'image_url': 'https://images.unsplash.com/photo-1621327017866-6fb07e6c96ea', 'difficulty': 'hard', 'duration_minutes': 180, 'steps_count': 10},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Quiche Lorraine', 'description': 'Savory tart with bacon and cheese', 'image_url': 'https://images.unsplash.com/photo-1600663791817-d74f5196ba29', 'difficulty': 'medium', 'duration_minutes': 50, 'steps_count': 6},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Tarte Tatin', 'description': 'Upside-down caramelized apple tart', 'image_url': 'https://images.unsplash.com/photo-1621327017866-6fb07e6c96ea', 'difficulty': 'medium', 'duration_minutes': 60, 'steps_count': 7},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Bouillabaisse', 'description': 'Traditional Provençal fish stew', 'image_url': 'https://images.unsplash.com/photo-1600663791817-d74f5196ba29', 'difficulty': 'hard', 'duration_minutes': 90, 'steps_count': 9},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Crêpes Suzette', 'description': 'Thin pancakes with orange butter sauce', 'image_url': 'https://images.unsplash.com/photo-1621327017866-6fb07e6c96ea', 'difficulty': 'medium', 'duration_minutes': 30, 'steps_count': 5},
        {'id': str(uuid.uuid4()), 'country_id': 'france', 'title': 'Cassoulet', 'description': 'Hearty white bean and meat casserole', 'image_url': 'https://images.unsplash.com/photo-1600663791817-d74f5196ba29', 'difficulty': 'hard', 'duration_minutes': 240, 'steps_count': 12},
        
        # Italy recipes
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Spaghetti Carbonara', 'description': 'Creamy pasta with eggs and pancetta', 'image_url': 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590', 'difficulty': 'easy', 'duration_minutes': 25, 'steps_count': 5},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Risotto alla Milanese', 'description': 'Creamy saffron risotto', 'image_url': 'https://images.unsplash.com/photo-1556761223-4c4282c73f77', 'difficulty': 'medium', 'duration_minutes': 40, 'steps_count': 6},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Osso Buco', 'description': 'Braised veal shanks with gremolata', 'image_url': 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590', 'difficulty': 'hard', 'duration_minutes': 150, 'steps_count': 9},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Tiramisu', 'description': 'Classic coffee-flavored dessert', 'image_url': 'https://images.unsplash.com/photo-1556761223-4c4282c73f77', 'difficulty': 'easy', 'duration_minutes': 30, 'steps_count': 6},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Margherita Pizza', 'description': 'Classic pizza with tomato, mozzarella, and basil', 'image_url': 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590', 'difficulty': 'medium', 'duration_minutes': 45, 'steps_count': 7},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Lasagna Bolognese', 'description': 'Layered pasta with meat sauce and béchamel', 'image_url': 'https://images.unsplash.com/photo-1556761223-4c4282c73f77', 'difficulty': 'medium', 'duration_minutes': 120, 'steps_count': 10},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Panna Cotta', 'description': 'Silky Italian custard dessert', 'image_url': 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590', 'difficulty': 'easy', 'duration_minutes': 20, 'steps_count': 4},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Bruschetta', 'description': 'Grilled bread with tomatoes and basil', 'image_url': 'https://images.unsplash.com/photo-1556761223-4c4282c73f77', 'difficulty': 'easy', 'duration_minutes': 15, 'steps_count': 4},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Fettuccine Alfredo', 'description': 'Creamy pasta with butter and parmesan', 'image_url': 'https://images.unsplash.com/photo-1516100882582-96c3a05fe590', 'difficulty': 'easy', 'duration_minutes': 20, 'steps_count': 4},
        {'id': str(uuid.uuid4()), 'country_id': 'italy', 'title': 'Saltimbocca', 'description': 'Veal with prosciutto and sage', 'image_url': 'https://images.unsplash.com/photo-1556761223-4c4282c73f77', 'difficulty': 'medium', 'duration_minutes': 30, 'steps_count': 6},
    ]
    await db.recipes.insert_many(recipes_data)

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
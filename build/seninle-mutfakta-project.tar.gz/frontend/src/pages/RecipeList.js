import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ArrowLeft, Clock, ChefHat } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function RecipeList() {
  const { countryId } = useParams();
  const [recipes, setRecipes] = useState([]);
  const [country, setCountry] = useState(null);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    loadRecipes();
    loadCountry();
  }, [countryId]);

  const loadCountry = async () => {
    try {
      const response = await axios.get(`${API}/countries`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const foundCountry = response.data.find(c => c.id === countryId);
      setCountry(foundCountry);
    } catch (error) {
      toast.error('Ülke bilgisi yüklenemedi');
    }
  };

  const loadRecipes = async () => {
    try {
      const response = await axios.get(`${API}/recipes?country_id=${countryId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      // Sort by difficulty: easy -> medium -> hard
      const sorted = response.data.sort((a, b) => {
        const order = { 'easy': 1, 'medium': 2, 'hard': 3 };
        return order[a.difficulty] - order[b.difficulty];
      });
      setRecipes(sorted);
    } catch (error) {
      toast.error('Tarifler yüklenemedi');
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-700';
      case 'medium': return 'bg-yellow-100 text-yellow-700';
      case 'hard': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getDifficultyText = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'Kolay';
      case 'medium': return 'Orta';
      case 'hard': return 'Zor';
      default: return difficulty;
    }
  };

  const getDifficultyIcon = (difficulty) => {
    switch (difficulty) {
      case 'easy': return '🌶';
      case 'medium': return '🌶🌶';
      case 'hard': return '🌶🌶🌶';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFE5D9] to-[#B8E6D5]">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Button
            data-testid="back-to-dashboard"
            variant="ghost"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="mr-2" /> Anasayfa
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        {country && (
          <div className="text-center mb-12 animate-fadeIn">
            <div className="text-7xl mb-4 animate-float">{country.flag}</div>
            <h1 className="text-4xl sm:text-5xl font-bold text-gradient mb-4">
              {country.name} Mutfağı
            </h1>
            <p className="text-lg text-gray-700">
              Birlikte yapabileceğiniz {recipes.length} harika tarif
            </p>
          </div>
        )}

        {/* Recipes grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe, index) => (
            <Card
              key={recipe.id}
              data-testid={`recipe-card-${recipe.id}`}
              className="card-glass overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer animate-fadeIn"
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => navigate(`/cooking/${recipe.id}`)}
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={recipe.image_url}
                  alt={recipe.title}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">{recipe.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{recipe.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{recipe.duration_minutes} dk</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getDifficultyColor(recipe.difficulty)}>
                      {getDifficultyIcon(recipe.difficulty)} {getDifficultyText(recipe.difficulty)}
                    </Badge>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
                  <ChefHat className="w-4 h-4" />
                  <span>{recipe.steps_count} adım</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
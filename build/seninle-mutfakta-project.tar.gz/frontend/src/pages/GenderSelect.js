import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function GenderSelect({ onGenderSelect }) {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const handleSelect = async (gender) => {
    setLoading(true);
    try {
      const response = await axios.post(`${API}/auth/select-gender`, 
        { gender },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      localStorage.setItem('user', JSON.stringify(response.data));
      toast.success('Profil oluşturuldu!');
      onGenderSelect(response.data);
      navigate('/dashboard');
    } catch (error) {
      toast.error('Bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-lavender flex items-center justify-center p-4">
      <Card className="card-glass border-none shadow-2xl max-w-md w-full animate-fadeIn">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-gradient mb-2">
            Sen Kimsin?
          </CardTitle>
          <CardDescription className="text-base">
            Eşinle birlikte yemek pişirmeye başlamadan önce, senin rolünü seç
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            data-testid="select-female"
            onClick={() => handleSelect('female')}
            disabled={loading}
            className="w-full py-8 text-lg btn-primary rounded-2xl flex items-center justify-center gap-4"
          >
            <span className="text-4xl">👩‍🍳</span>
            <span className="font-bold">Kadınım</span>
          </Button>

          <Button
            data-testid="select-male"
            onClick={() => handleSelect('male')}
            disabled={loading}
            className="w-full py-8 text-lg btn-primary rounded-2xl flex items-center justify-center gap-4"
          >
            <span className="text-4xl">👨‍🍳</span>
            <span className="font-bold">Erkeğim</span>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
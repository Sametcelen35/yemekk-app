import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Lock, Users, Home, LogOut } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function Dashboard({ user, onLogout }) {
  const [countries, setCountries] = useState([]);
  const [couple, setCouple] = useState(null);
  const [showCoupleDialog, setShowCoupleDialog] = useState(false);
  const [coupleData, setCoupleData] = useState({ female_name: '', male_name: '' });
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    loadCountries();
    loadCouple();
  }, []);

  const loadCountries = async () => {
    try {
      const response = await axios.get(`${API}/countries`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCountries(response.data);
    } catch (error) {
      toast.error('Ülkeler yüklenemedi');
    }
  };

  const loadCouple = async () => {
    try {
      const response = await axios.get(`${API}/couples/me`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCouple(response.data);
    } catch (error) {
      if (error.response?.status === 404) {
        setShowCoupleDialog(true);
      }
    }
  };

  const handleCreateCouple = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API}/couples`, coupleData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCouple(response.data);
      setShowCoupleDialog(false);
      toast.success('Çift profili oluşturuldu!');
    } catch (error) {
      toast.error('Bir hata oluştu');
    }
  };

  const getCountryIcon = (countryId) => {
    const icons = {
      'france': '🗼', // Eiffel Tower
      'italy': '🍕', // Pizza
      'turkey': '🧿', // Nazar boncuğu
      'japan': '🍱', // Bento box
      'mexico': '🌮', // Taco
    };
    return icons[countryId] || '🍽️';
  };

  const handleCountryClick = (country) => {
    if (country.is_unlocked) {
      navigate(`/recipes/${country.id}`);
    } else {
      toast.info('Bu ülke henüz kilitli!');
    }
  };

  return (
    <div className="min-h-screen gradient-lavender">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Home className="w-6 h-6 text-[#E0BBE4]" />
            <h1 className="text-2xl font-bold text-gradient">Seninle Mutfakta</h1>
          </div>
          <div className="flex items-center gap-4">
            {couple && (
              <div className="hidden sm:flex items-center gap-2 card-glass px-4 py-2 rounded-full">
                <Users className="w-5 h-5 text-[#FFB8B8]" />
                <span className="text-sm font-semibold">{couple.female_name} & {couple.male_name}</span>
              </div>
            )}
            <Button
              data-testid="social-button"
              variant="outline"
              onClick={() => navigate('/social')}
              className="rounded-full"
            >
              Sosyal
            </Button>
            <Button
              data-testid="profile-button"
              variant="outline"
              onClick={() => navigate('/profile')}
              className="rounded-full"
            >
              Profil
            </Button>
            <Button
              data-testid="logout-button"
              variant="ghost"
              onClick={onLogout}
              className="rounded-full"
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12 animate-fadeIn">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Hangi Ülkeyi Keşfetmek İstersiniz?
          </h2>
          <p className="text-lg text-white/90">
            Birlikte yemek pişirme maceranıza başlayın
          </p>
        </div>

        {/* Countries grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {countries.map((country, index) => (
            <Card
              key={country.id}
              data-testid={`country-card-${country.id}`}
              className={`relative overflow-hidden cursor-pointer hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-fadeIn ${
                country.is_unlocked ? '' : 'opacity-60'
              }`}
              style={{ 
                animationDelay: `${index * 0.1}s`,
                background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)`
              }}
              onClick={() => handleCountryClick(country)}
            >
              {/* Flag background */}
              <div className="absolute inset-0 opacity-20 text-9xl flex items-center justify-center">
                {country.flag}
              </div>
              
              {/* Country icon overlay */}
              <div className="absolute top-4 right-4 text-4xl animate-float">
                {getCountryIcon(country.id)}
              </div>
              
              <CardContent className="relative z-10 p-6">
                <div className="text-center">
                  <div className="text-6xl mb-4 animate-float" style={{ animationDelay: `${index * 0.2}s` }}>
                    {country.flag}
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{country.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    {country.recipes_count} Tarif
                  </p>
                  {!country.is_unlocked && (
                    <div className="flex items-center justify-center gap-2 text-gray-500">
                      <Lock className="w-4 h-4" />
                      <span className="text-sm font-semibold">Kilitli</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      {/* Couple creation dialog */}
      <Dialog open={showCoupleDialog} onOpenChange={(open) => {
        // Prevent closing the dialog if couple is not created
        if (!open && !couple) return;
        setShowCoupleDialog(open);
      }}>
        <DialogContent className="card-glass">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gradient">Çift Profilinizi Oluşturun</DialogTitle>
            <DialogDescription>
              Birlikte yemek yapacağınız isimlerinizi girin
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateCouple} className="space-y-4 mt-4">
            <div>
              <Label htmlFor="female_name">Kadın İsmi</Label>
              <Input
                data-testid="female-name-input"
                id="female_name"
                placeholder="Örn: Ayşe"
                value={coupleData.female_name}
                onChange={(e) => setCoupleData({ ...coupleData, female_name: e.target.value })}
                required
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="male_name">Erkek İsmi</Label>
              <Input
                data-testid="male-name-input"
                id="male_name"
                placeholder="Örn: Mehmet"
                value={coupleData.male_name}
                onChange={(e) => setCoupleData({ ...coupleData, male_name: e.target.value })}
                required
                className="mt-1"
              />
            </div>
            <Button data-testid="create-couple-button" type="submit" className="w-full btn-primary">
              Profili Oluştur
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Heart, ChefHat, Users } from 'lucide-react';

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen gradient-peach flex flex-col items-center justify-center p-4">
      {/* Animated couple cooking illustration */}
      <div className="relative mb-12 animate-fadeIn">
        <div className="w-80 h-80 relative">
          <img 
            src="https://images.unsplash.com/photo-1753392785049-1bf269637ecc" 
            alt="Couple cooking together" 
            className="w-full h-full object-cover rounded-full shadow-2xl"
          />
          <div className="absolute -top-4 -right-4 w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg animate-float">
            <Heart className="w-10 h-10 text-[#FFB8B8] animate-heart" fill="#FFB8B8" />
          </div>
          <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg animate-float" style={{animationDelay: '0.5s'}}>
            <ChefHat className="w-10 h-10 text-[#B8E6D5]" />
          </div>
        </div>
      </div>

      {/* Title */}
      <div className="text-center mb-8 animate-fadeIn" style={{animationDelay: '0.2s'}}>
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gradient mb-4">
          Seninle Mutfakta
        </h1>
        <p className="text-sm sm:text-base text-[#4A4A4A] max-w-xl mx-auto leading-snug">
          Eşinle birlikte farklı ülkelerin tariflerini keşfet ve birlikte eğlenceli anlar yaşa.
        </p>
      </div>

      {/* Feature highlights - Horizontal Scroll */}
      <div className="mb-8 animate-fadeIn overflow-x-auto" style={{animationDelay: '0.4s'}}>
        <div className="flex gap-4 justify-start px-4 min-w-max mx-auto" style={{width: 'fit-content'}}>
          <div className="card-glass p-4 text-center hover:bg-[#FFE5D9] transition-colors cursor-pointer flex-shrink-0 w-36">
            <Users className="w-6 h-6 text-[#FFB8B8] mx-auto mb-2" />
            <p className="text-xs font-semibold text-[#4A4A4A]">Eş Zamanlı Mod</p>
          </div>
          <div className="card-glass p-4 text-center hover:bg-[#FFE5D9] transition-colors cursor-pointer flex-shrink-0 w-36">
            <ChefHat className="w-6 h-6 text-[#B8E6D5] mx-auto mb-2" />
            <p className="text-xs font-semibold text-[#4A4A4A]">50+ Tarif</p>
          </div>
          <div className="card-glass p-4 text-center hover:bg-[#FFE5D9] transition-colors cursor-pointer flex-shrink-0 w-36">
            <Heart className="w-6 h-6 text-[#E0BBE4] mx-auto mb-2" />
            <p className="text-xs font-semibold text-[#4A4A4A]">Pasaport Rozetleri</p>
          </div>
          <div className="card-glass p-4 text-center hover:bg-[#FFE5D9] transition-colors cursor-pointer flex-shrink-0 w-36">
            <Users className="w-6 h-6 text-[#FFB8B8] mx-auto mb-2" />
            <p className="text-xs font-semibold text-[#4A4A4A]">Çift Profili</p>
          </div>
        </div>
      </div>

      {/* Passport/Badge Preview */}
      <div className="mb-12 animate-fadeIn" style={{animationDelay: '0.5s'}}>
        <h3 className="text-2xl font-bold text-center mb-6 text-[#4A4A4A]">Rozetlerini Kazan! 🏆</h3>
        <div className="flex flex-wrap gap-4 justify-center">
          <div className="card-glass p-4 text-center">
            <div className="text-3xl mb-2">🔰</div>
            <p className="text-xs font-semibold">Yeni Başlayan</p>
          </div>
          <div className="card-glass p-4 text-center">
            <div className="text-3xl mb-2">🧑‍🍳</div>
            <p className="text-xs font-semibold">Deneyimli Şef</p>
          </div>
          <div className="card-glass p-4 text-center">
            <div className="text-3xl mb-2">👨‍🍳</div>
            <p className="text-xs font-semibold">Usta Aşçı</p>
          </div>
          <div className="card-glass p-4 text-center">
            <div className="text-3xl mb-2">🏆</div>
            <p className="text-xs font-semibold">Efsane</p>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-row gap-4 justify-center animate-fadeIn" style={{animationDelay: '0.6s'}}>
        <Button 
          data-testid="register-button"
          className="btn-primary text-base px-8 py-6 rounded-full hover:shadow-lg transition-all"
          onClick={() => navigate('/auth?mode=register')}
        >
          Kayıt Ol
        </Button>
        <Button 
          data-testid="login-button"
          className="btn-secondary text-base px-8 py-6 rounded-full hover:bg-[#FFB8B8] hover:text-white transition-all"
          onClick={() => navigate('/auth?mode=login')}
        >
          Giriş Yap
        </Button>
      </div>
    </div>
  );
}
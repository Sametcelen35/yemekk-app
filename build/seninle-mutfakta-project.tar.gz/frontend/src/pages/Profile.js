import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { ArrowLeft, Award, ChefHat, Trophy, LogOut, Settings } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function Profile({ user, onLogout }) {
  const [progress, setProgress] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [completedCount, setCompletedCount] = useState(0);
  const [showGenderDialog, setShowGenderDialog] = useState(false);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    loadProgress();
    loadRecipes();
  }, []);

  const loadProgress = async () => {
    try {
      const response = await axios.get(`${API}/progress`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProgress(response.data);
      const completed = response.data.filter(p => p.completed).length;
      setCompletedCount(completed);
    } catch (error) {
      toast.error('İlerleme yüklenemedi');
    }
  };

  const loadRecipes = async () => {
    try {
      const response = await axios.get(`${API}/recipes`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecipes(response.data);
    } catch (error) {
      console.error('Recipes load error:', error);
    }
  };

  const getBadgeForCount = (count) => {
    if (count >= 20) return { name: 'Usta Aşçı', icon: '👨‍🍳', color: 'bg-yellow-100 text-yellow-700' };
    if (count >= 10) return { name: 'Deneyimli Şef', icon: '🧑‍🍳', color: 'bg-blue-100 text-blue-700' };
    if (count >= 5) return { name: 'Mutfak Dostu', icon: '👩‍🍳', color: 'bg-green-100 text-green-700' };
    return { name: 'Yeni Başlayan', icon: '🔰', color: 'bg-gray-100 text-gray-700' };
  };

  const handleChangeGender = async (newGender) => {
    try {
      const response = await axios.post(`${API}/auth/select-gender`, 
        { gender: newGender },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      localStorage.setItem('user', JSON.stringify(response.data));
      toast.success('Cinsiyet güncellendi!');
      setShowGenderDialog(false);
      window.location.reload(); // Refresh to update UI
    } catch (error) {
      toast.error('Bir hata oluştu');
    }
  };

  const currentBadge = getBadgeForCount(completedCount);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFE5D9] to-[#E0BBE4]">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <Button
            data-testid="back-to-dashboard"
            variant="ghost"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="mr-2" /> Anasayfa
          </Button>
          <h1 className="text-2xl font-bold text-gradient">Profilim</h1>
          <Button
            data-testid="logout-button"
            variant="ghost"
            onClick={onLogout}
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* User info card */}
        <Card className="card-glass mb-8 animate-fadeIn">
          <CardContent className="p-8 text-center">
            <div className="w-24 h-24 bg-gradient-to-br from-[#FFB8B8] to-[#E0BBE4] rounded-full mx-auto mb-4 flex items-center justify-center relative">
              <span className="text-4xl font-bold text-white">
                {user?.name?.charAt(0).toUpperCase()}
              </span>
              <button 
                onClick={() => setShowGenderDialog(true)}
                className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-50 transition-colors"
              >
                <Settings className="w-4 h-4 text-gray-600" />
              </button>
            </div>
            <h2 className="text-2xl font-bold mb-2">{user?.name}</h2>
            <p className="text-gray-600 mb-2">{user?.email}</p>
            <p className="text-sm text-gray-500 mb-4">
              {user?.gender === 'female' ? '👩‍🍳 Kadın' : '👨‍🍳 Erkek'}
            </p>
            
            {/* Current badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 rounded-full">
              <span className="text-2xl">{currentBadge.icon}</span>
              <span className="font-semibold">{currentBadge.name}</span>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="card-glass animate-fadeIn" style={{animationDelay: '0.1s'}}>
            <CardContent className="p-6 text-center">
              <ChefHat className="w-12 h-12 text-[#FFB8B8] mx-auto mb-2" />
              <p className="text-3xl font-bold mb-1">{completedCount}</p>
              <p className="text-sm text-gray-600">Tamamlanan Tarif</p>
            </CardContent>
          </Card>

          <Card className="card-glass animate-fadeIn" style={{animationDelay: '0.2s'}}>
            <CardContent className="p-6 text-center">
              <Trophy className="w-12 h-12 text-[#B8E6D5] mx-auto mb-2" />
              <p className="text-3xl font-bold mb-1">{Math.floor(completedCount / 5)}</p>
              <p className="text-sm text-gray-600">Kazanılan Rozet</p>
            </CardContent>
          </Card>

          <Card className="card-glass animate-fadeIn" style={{animationDelay: '0.3s'}}>
            <CardContent className="p-6 text-center">
              <Award className="w-12 h-12 text-[#E0BBE4] mx-auto mb-2" />
              <p className="text-3xl font-bold mb-1">{recipes.length}</p>
              <p className="text-sm text-gray-600">Toplam Tarif</p>
            </CardContent>
          </Card>
        </div>

        {/* Badges */}
        <Card className="card-glass animate-fadeIn" style={{animationDelay: '0.4s'}}>
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Rozetler</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className={`p-4 rounded-lg text-center ${completedCount >= 5 ? 'bg-white/80' : 'bg-gray-200/50 opacity-50'}`}>
                <div className="text-4xl mb-2">🔰</div>
                <p className="text-xs font-semibold">Yeni Başlayan</p>
                <p className="text-xs text-gray-500">5 tarif</p>
              </div>
              
              <div className={`p-4 rounded-lg text-center ${completedCount >= 10 ? 'bg-white/80' : 'bg-gray-200/50 opacity-50'}`}>
                <div className="text-4xl mb-2">🧑‍🍳</div>
                <p className="text-xs font-semibold">Deneyimli Şef</p>
                <p className="text-xs text-gray-500">10 tarif</p>
              </div>
              
              <div className={`p-4 rounded-lg text-center ${completedCount >= 20 ? 'bg-white/80' : 'bg-gray-200/50 opacity-50'}`}>
                <div className="text-4xl mb-2">👨‍🍳</div>
                <p className="text-xs font-semibold">Usta Aşçı</p>
                <p className="text-xs text-gray-500">20 tarif</p>
              </div>
              
              <div className={`p-4 rounded-lg text-center ${completedCount >= 50 ? 'bg-white/80' : 'bg-gray-200/50 opacity-50'}`}>
                <div className="text-4xl mb-2">🏆</div>
                <p className="text-xs font-semibold">Efsane</p>
                <p className="text-xs text-gray-500">50 tarif</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Gender change dialog */}
      <Dialog open={showGenderDialog} onOpenChange={setShowGenderDialog}>
        <DialogContent className="card-glass">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gradient">Cinsiyet Değiştir</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <Button
              onClick={() => handleChangeGender('female')}
              className="w-full py-6 text-lg btn-primary rounded-2xl flex items-center justify-center gap-4"
            >
              <span className="text-3xl">👩‍🍳</span>
              <span className="font-bold">Kadınım</span>
            </Button>
            <Button
              onClick={() => handleChangeGender('male')}
              className="w-full py-6 text-lg btn-primary rounded-2xl flex items-center justify-center gap-4"
            >
              <span className="text-3xl">👨‍🍳</span>
              <span className="font-bold">Erkeğim</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
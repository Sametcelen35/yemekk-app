import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { ArrowLeft, Users, Play, Check } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function CookingMode({ user }) {
  const { recipeId } = useParams();
  const [recipe, setRecipe] = useState(null);
  const [steps, setSteps] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [syncMode, setSyncMode] = useState(false);
  const [showSyncDialog, setShowSyncDialog] = useState(true);
  const [view, setView] = useState('both'); // 'female', 'male', 'both'
  const [showMiniGame, setShowMiniGame] = useState(false);
  const [gameWinner, setGameWinner] = useState(null);
  const [partnerStep, setPartnerStep] = useState(0);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    loadRecipe();
    loadSteps();
  }, [recipeId]);

  // Poll partner progress every 5 seconds when in sync mode
  useEffect(() => {
    if (syncMode) {
      const interval = setInterval(() => {
        loadPartnerProgress();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [syncMode, recipeId]);

  const loadPartnerProgress = async () => {
    try {
      const response = await axios.get(`${API}/progress/partner/${recipeId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPartnerStep(response.data.current_step || 0);
    } catch (error) {
      console.error('Partner progress load error:', error);
    }
  };

  const loadRecipe = async () => {
    try {
      const response = await axios.get(`${API}/recipes/${recipeId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecipe(response.data);
    } catch (error) {
      toast.error('Tarif yüklenemedi');
    }
  };

  const loadSteps = async () => {
    try {
      const response = await axios.get(`${API}/recipes/${recipeId}/steps`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.data && response.data.length > 0) {
        setSteps(response.data);
      } else {
        // If no steps, create default ones
        const defaultSteps = [
          { id: '1', recipe_id: recipeId, step_number: 1, title: 'Malzemeleri Hazırlayın', description: 'Tüm malzemeleri tezgaha dizin ve ölçülerinizi yapın', animation_type: 'mix', duration_seconds: 180 },
          { id: '2', recipe_id: recipeId, step_number: 2, title: 'Doğrayın', description: 'Sebzeleri ince ince doğrayın', animation_type: 'chop', duration_seconds: 300 },
          { id: '3', recipe_id: recipeId, step_number: 3, title: 'Pişirin', description: 'Tavada orta ateşte pişirin', animation_type: 'cook', duration_seconds: 600 },
          { id: '4', recipe_id: recipeId, step_number: 4, title: 'Karıştırın', description: 'İçerikleri iyice karıştırın', animation_type: 'stir', duration_seconds: 240 },
          { id: '5', recipe_id: recipeId, step_number: 5, title: 'Servis Yapın', description: 'Tabaklara güzelçe servis yapın', animation_type: 'pour', duration_seconds: 120 },
        ];
        setSteps(defaultSteps);
      }
    } catch (error) {
      // If error, create default ones
      const defaultSteps = [
        { id: '1', recipe_id: recipeId, step_number: 1, title: 'Malzemeleri Hazırlayın', description: 'Tüm malzemeleri tezgaha dizin ve ölçülerinizi yapın', animation_type: 'mix', duration_seconds: 180 },
        { id: '2', recipe_id: recipeId, step_number: 2, title: 'Doğrayın', description: 'Sebzeleri ince ince doğrayın', animation_type: 'chop', duration_seconds: 300 },
        { id: '3', recipe_id: recipeId, step_number: 3, title: 'Pişirin', description: 'Tavada orta ateşte pişirin', animation_type: 'cook', duration_seconds: 600 },
        { id: '4', recipe_id: recipeId, step_number: 4, title: 'Karıştırın', description: 'İçerikleri iyice karıştırın', animation_type: 'stir', duration_seconds: 240 },
        { id: '5', recipe_id: recipeId, step_number: 5, title: 'Servis Yapın', description: 'Tabaklara güzelçe servis yapın', animation_type: 'pour', duration_seconds: 120 },
      ];
      setSteps(defaultSteps);
    }
  };

  const handleStartSync = () => {
    setSyncMode(true);
    setShowSyncDialog(false);
  };

  const handleStartSolo = () => {
    setSyncMode(false);
    setShowSyncDialog(false);
  };

  const handleNextStep = () => {
    if (currentStep < steps.length - 1) {
      const newStep = currentStep + 1;
      setCurrentStep(newStep);
      // Update progress in backend
      updateProgress(newStep, false);
    } else {
      // Recipe completed, show mini game
      updateProgress(currentStep, true);
      setShowMiniGame(true);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 0) {
      const newStep = currentStep - 1;
      setCurrentStep(newStep);
      // Update progress in backend
      updateProgress(newStep, false);
    }
  };

  const updateProgress = async (step, completed) => {
    try {
      await axios.post(`${API}/progress`, {
        recipe_id: recipeId,
        current_step: step,
        completed: completed
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (error) {
      console.error('Progress update error:', error);
    }
  };

  const handleCompleteRecipe = async () => {
    try {
      await axios.post(`${API}/progress`, {
        recipe_id: recipeId,
        completed: true
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success('Tarif tamamlandı! Sosyal alanında paylaşabilirsin.');
      navigate('/social');
    } catch (error) {
      toast.error('Bir hata oluştu');
    }
  };

  const playMiniGame = () => {
    // Simple random winner selection
    const winner = Math.random() > 0.5 ? 'female' : 'male';
    setGameWinner(winner);
  };

  const getAnimationClass = (animationType) => {
    switch (animationType) {
      case 'chop': return 'animate-chop';
      case 'stir': return 'animate-stir';
      case 'pour': return 'animate-pour';
      case 'mix': return 'animate-mix';
      case 'cook': return 'animate-cook';
      default: return 'animate-pulse';
    }
  };

  const currentStepData = steps[currentStep];
  const progress = steps.length > 0 ? ((currentStep + 1) / steps.length) * 100 : 0;

  if (!recipe) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E0BBE4] to-[#FFE5D9]">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <Button
            data-testid="back-button"
            variant="ghost"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="mr-2" /> Geri
          </Button>
          <h1 className="text-xl font-bold text-gradient">{recipe.title}</h1>
          <div className="w-20"></div> {/* Spacer for centering */}
        </div>
      </header>

      {/* Progress bar */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-2 flex justify-between text-sm font-semibold">
          <span>Adım {currentStep + 1} / {steps.length}</span>
          <span>%{Math.round(progress)}</span>
        </div>
        <Progress value={progress} className="h-3" />
      </div>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {currentStepData && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* My card - based on user gender */}
            {user && (
              <Card className="card-glass animate-fadeIn mx-auto max-w-2xl" data-testid={`step-card-${user.gender}`}>
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="inline-block mb-4">
                      <div className={`text-6xl ${getAnimationClass(currentStepData.animation_type)}`}>
                        {user.gender === 'female' ? '👩‍🍳' : '👨‍🍳'}
                      </div>
                    </div>
                    <h2 className="text-2xl font-bold mb-2">{currentStepData.title}</h2>
                    <p className="text-gray-700 text-lg">{currentStepData.description}</p>
                  </div>
                  <div className="mt-6 p-4 bg-white/50 rounded-lg">
                    <p className="text-sm text-gray-600 text-center">
                      Tahmini süre: {Math.floor(currentStepData.duration_seconds / 60)} dakika
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Navigation buttons */}
        <div className="flex justify-center gap-4 mt-8">
          <Button
            data-testid="previous-step-button"
            variant="outline"
            onClick={handlePreviousStep}
            disabled={currentStep === 0}
            className="px-8 py-6 rounded-full"
          >
            Önceki
          </Button>
          <Button
            data-testid="next-step-button"
            className="btn-primary px-8 py-6 rounded-full"
            onClick={handleNextStep}
          >
            {currentStep === steps.length - 1 ? 'Bitir' : 'Sonraki'}
            {currentStep === steps.length - 1 ? <Check className="ml-2" /> : <Play className="ml-2" />}
          </Button>
        </div>
      </main>

      {/* Sync mode dialog */}
      <Dialog open={showSyncDialog} onOpenChange={setShowSyncDialog}>
        <DialogContent className="card-glass">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gradient">Birlikte mi yapmak istiyorsunuz?</DialogTitle>
            <DialogDescription className="text-base">
              Eş zamanlı modda her ikiniz de adımları birlikte takip edebilirsiniz
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-4">
            <Button
              data-testid="sync-mode-button"
              className="btn-primary py-6"
              onClick={handleStartSync}
            >
              <Users className="mr-2" /> Evet, Birlikte Yapalım
            </Button>
            <Button
              data-testid="solo-mode-button"
              variant="outline"
              className="py-6"
              onClick={handleStartSolo}
            >
              Tek Başıma Yapacağım
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Mini game dialog */}
      <Dialog open={showMiniGame} onOpenChange={setShowMiniGame}>
        <DialogContent className="card-glass">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gradient">Sofrayı Kim Kursun?</DialogTitle>
            <DialogDescription className="text-base">
              Mini oyun zamanı! Kaybeden sofrayı kuracak 😄
            </DialogDescription>
          </DialogHeader>
          <div className="py-8">
            {!gameWinner ? (
              <Button
                data-testid="play-game-button"
                className="btn-primary w-full py-6 text-lg"
                onClick={playMiniGame}
              >
                Kura Çek!
              </Button>
            ) : (
              <div className="text-center animate-fadeIn">
                <div className="text-7xl mb-4 animate-float">
                  {gameWinner === 'female' ? '👨‍🍳' : '👩‍🍳'}
                </div>
                <h3 className="text-2xl font-bold mb-4">
                  {gameWinner === 'female' ? 'Erkek' : 'Kadın'} Sofrayı Kuracak!
                </h3>
                <p className="text-gray-600 mb-6">
                  Aferin, harika bir yemek yaptınız! 🍴
                </p>
                <Button
                  data-testid="complete-recipe-button"
                  className="btn-primary"
                  onClick={handleCompleteRecipe}
                >
                  Tarifi Tamamla ve Paylaş
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
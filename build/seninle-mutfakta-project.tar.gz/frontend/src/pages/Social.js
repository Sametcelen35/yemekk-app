import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ArrowLeft, Heart, MessageCircle, Send, Plus } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function Social({ user }) {
  const [posts, setPosts] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showCommentsDialog, setShowCommentsDialog] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [newPost, setNewPost] = useState({ recipe_id: '', image_url: '', caption: '' });
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [uploadingImage, setUploadingImage] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    loadPosts();
    loadRecipes();
  }, []);

  const loadPosts = async () => {
    setLoadingPosts(true);
    try {
      const response = await axios.get(`${API}/posts`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPosts(response.data);
      
      // Check which posts are liked
      const liked = new Set();
      for (const post of response.data) {
        const likeCheck = await axios.get(`${API}/posts/${post.id}/is-liked`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (likeCheck.data.liked) {
          liked.add(post.id);
        }
      }
      setLikedPosts(liked);
    } catch (error) {
      toast.error('Paylaşımlar yüklenemedi');
    } finally {
      setLoadingPosts(false);
    }
  };

  const loadRecipes = async () => {
    try {
      const response = await axios.get(`${API}/recipes`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecipes(response.data);
    } catch (error) {
      console.error('Recipes load error:', error);
    }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    
    // Upload image first if file is selected
    if (selectedFile && !newPost.image_url) {
      try {
        setUploadingImage(true);
        const formData = new FormData();
        formData.append('file', selectedFile);
        
        const uploadResponse = await axios.post(`${API}/upload-image`, formData, {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        });
        
        setNewPost({ ...newPost, image_url: uploadResponse.data.image_url });
        setUploadingImage(false);
        
        // Now create post with uploaded image
        await axios.post(`${API}/posts`, 
          { ...newPost, image_url: uploadResponse.data.image_url },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      } catch (error) {
        setUploadingImage(false);
        toast.error('Resim yüklenirken hata oluştu');
        return;
      }
    } else {
      // Create post with existing image URL
      try {
        await axios.post(`${API}/posts`, newPost, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (error) {
        toast.error('Bir hata oluştu');
        return;
      }
    }
    
    toast.success('Paylaşım oluşturuldu!');
    setShowCreateDialog(false);
    setNewPost({ recipe_id: '', image_url: '', caption: '' });
    setSelectedFile(null);
    loadPosts();
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('Dosya boyutu 5MB\'dan küçük olmalı');
        return;
      }
      setSelectedFile(file);
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPost({ ...newPost, image_url: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLike = async (postId) => {
    try {
      await axios.post(`${API}/posts/${postId}/like`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      // Update local state
      const newLikedPosts = new Set(likedPosts);
      if (newLikedPosts.has(postId)) {
        newLikedPosts.delete(postId);
      } else {
        newLikedPosts.add(postId);
      }
      setLikedPosts(newLikedPosts);
      
      // Reload posts to update counts
      loadPosts();
    } catch (error) {
      toast.error('Bir hata oluştu');
    }
  };

  const handleShowComments = async (post) => {
    setSelectedPost(post);
    try {
      const response = await axios.get(`${API}/posts/${post.id}/comments`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setComments(response.data);
      setShowCommentsDialog(true);
    } catch (error) {
      toast.error('Yorumlar yüklenemedi');
    }
  };

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    try {
      await axios.post(`${API}/posts/${selectedPost.id}/comments`, 
        { text: newComment },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewComment('');
      // Reload comments
      const response = await axios.get(`${API}/posts/${selectedPost.id}/comments`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setComments(response.data);
      loadPosts(); // Update comment count
      toast.success('Yorum eklendi');
    } catch (error) {
      toast.error('Bir hata oluştu');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#B8E6D5] to-[#FFE5D9]">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <Button
            data-testid="back-to-dashboard"
            variant="ghost"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="mr-2" /> Ana Sayfa
          </Button>
          <h1 className="text-2xl font-bold text-gradient">Seninle Sosyal</h1>
          <Button
            data-testid="create-post-button"
            className="btn-primary rounded-full"
            onClick={() => setShowCreateDialog(true)}
          >
            <Plus className="mr-2" /> Paylaş
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {loadingPosts ? (
          <Card className="card-glass p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FFB8B8]"></div>
              <p className="text-gray-600">Paylaşımlar yükleniyor...</p>
            </div>
          </Card>
        ) : posts.length === 0 ? (
          <Card className="card-glass p-12 text-center">
            <p className="text-gray-600 text-lg mb-4">Henüz paylaşım yok</p>
            <Button
              data-testid="first-post-button"
              className="btn-primary"
              onClick={() => setShowCreateDialog(true)}
            >
              İlk Paylaşımı Yap
            </Button>
          </Card>
        ) : (
          <div className="space-y-6">
            {posts.map((post, index) => (
              <Card key={post.id} data-testid={`post-${post.id}`} className="card-glass animate-fadeIn" style={{animationDelay: `${index * 0.1}s`}}>
                <CardContent className="p-0">
                  {/* Post image */}
                  <div className="aspect-video overflow-hidden rounded-t-lg">
                    <img
                      src={post.image_url}
                      alt="Post"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Post content */}
                  <div className="p-6">
                    <p className="text-gray-800 mb-4">{post.caption}</p>

                    {/* Actions */}
                    <div className="flex items-center gap-6">
                      <button
                        data-testid={`like-button-${post.id}`}
                        onClick={() => handleLike(post.id)}
                        className="flex items-center gap-2 hover:scale-110 transition-transform"
                      >
                        <Heart
                          className={`w-6 h-6 ${likedPosts.has(post.id) ? 'fill-[#FFB8B8] text-[#FFB8B8] animate-heart' : 'text-gray-600'}`}
                        />
                        <span className="text-sm font-semibold">{post.likes_count}</span>
                      </button>

                      <button
                        data-testid={`comment-button-${post.id}`}
                        onClick={() => handleShowComments(post)}
                        className="flex items-center gap-2 hover:scale-110 transition-transform"
                      >
                        <MessageCircle className="w-6 h-6 text-gray-600" />
                        <span className="text-sm font-semibold">{post.comments_count}</span>
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Create post dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="card-glass">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gradient">Yeni Paylaşım</DialogTitle>
            <DialogDescription>Yaptığınız yemeği paylaşın</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreatePost} className="space-y-4 mt-4">
            <div>
              <label className="text-sm font-semibold mb-2 block">Tarif</label>
              <select
                data-testid="recipe-select"
                value={newPost.recipe_id}
                onChange={(e) => setNewPost({ ...newPost, recipe_id: e.target.value })}
                required
                className="w-full px-3 py-2 border rounded-md"
              >
                <option value="">Tarif seçin</option>
                {recipes.map(recipe => (
                  <option key={recipe.id} value={recipe.id}>{recipe.title}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block">Yemek Fotoğrafı</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                {newPost.image_url ? (
                  <div className="relative">
                    <img src={newPost.image_url} alt="Preview" className="max-h-48 mx-auto rounded" />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="mt-2"
                      onClick={() => {
                        setNewPost({ ...newPost, image_url: '' });
                        setSelectedFile(null);
                      }}
                    >
                      Sil
                    </Button>
                  </div>
                ) : (
                  <div>
                    <input
                      type="file"
                      id="image-upload"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <label
                      htmlFor="image-upload"
                      className="cursor-pointer inline-block px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                    >
                      📸 Dosyadan Seç
                    </label>
                    <p className="text-xs text-gray-500 mt-2">veya</p>
                    <Input
                      data-testid="image-url-input"
                      placeholder="Resim URL girin"
                      value={newPost.image_url}
                      onChange={(e) => setNewPost({ ...newPost, image_url: e.target.value })}
                      className="mt-2"
                    />
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Açıklama</label>
              <Textarea
                data-testid="caption-input"
                placeholder="Yemeğiniz hakkında bir şeyler yazın..."
                value={newPost.caption}
                onChange={(e) => setNewPost({ ...newPost, caption: e.target.value })}
                required
                rows={4}
              />
            </div>

            <Button 
              data-testid="submit-post-button" 
              type="submit" 
              className="w-full btn-primary"
              disabled={uploadingImage}
            >
              {uploadingImage ? 'Yükleniyor...' : 'Paylaş'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Comments dialog */}
      <Dialog open={showCommentsDialog} onOpenChange={setShowCommentsDialog}>
        <DialogContent className="card-glass max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl text-gradient">Yorumlar</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            {comments.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Henüz yorum yok</p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} data-testid={`comment-${comment.id}`} className="p-4 bg-white/50 rounded-lg">
                  <p className="font-semibold text-sm text-[#FFB8B8] mb-1">{comment.user_name}</p>
                  <p className="text-gray-800">{comment.text}</p>
                </div>
              ))
            )}
          </div>

          {/* Add comment form */}
          <form onSubmit={handleAddComment} className="flex gap-2 mt-4">
            <Input
              data-testid="comment-input"
              placeholder="Yorum ekle..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
            />
            <Button data-testid="send-comment-button" type="submit" size="icon" className="btn-primary">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import '@/App.css';
import { Toaster } from '@/components/ui/sonner';
import Landing from '@/pages/Landing';
import Auth from '@/pages/Auth';
import GenderSelect from '@/pages/GenderSelect';
import Dashboard from '@/pages/Dashboard';
import RecipeList from '@/pages/RecipeList';
import CookingMode from '@/pages/CookingMode';
import Social from '@/pages/Social';
import Profile from '@/pages/Profile';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleAuth = (authToken, userData) => {
    setToken(authToken);
    setUser(userData);
    localStorage.setItem('token', authToken);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleGenderSelect = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  // Check if user needs to select gender
  const needsGenderSelection = token && user && !user.gender;

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={token ? (needsGenderSelection ? <Navigate to="/gender-select" /> : <Navigate to="/dashboard" />) : <Landing />} />
          <Route path="/auth" element={token ? <Navigate to="/dashboard" /> : <Auth onAuth={handleAuth} />} />
          <Route path="/gender-select" element={token ? (needsGenderSelection ? <GenderSelect onGenderSelect={handleGenderSelect} /> : <Navigate to="/dashboard" />) : <Navigate to="/" />} />
          <Route path="/dashboard" element={token && !needsGenderSelection ? <Dashboard user={user} onLogout={handleLogout} /> : <Navigate to={needsGenderSelection ? "/gender-select" : "/"} />} />
          <Route path="/recipes/:countryId" element={token && !needsGenderSelection ? <RecipeList /> : <Navigate to="/" />} />
          <Route path="/cooking/:recipeId" element={token && !needsGenderSelection ? <CookingMode user={user} /> : <Navigate to="/" />} />
          <Route path="/social" element={token && !needsGenderSelection ? <Social user={user} /> : <Navigate to="/" />} />
          <Route path="/profile" element={token && !needsGenderSelection ? <Profile user={user} onLogout={handleLogout} /> : <Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </div>
  );
}

export default App;
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../config/api';

export default function DashboardScreen({ navigation }) {
  const [countries, setCountries] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const userData = await AsyncStorage.getItem('user');
      setUser(JSON.parse(userData));

      const response = await axios.get(`${API_URL}/countries`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCountries(response.data);
    } catch (error) {
      Alert.alert('Hata', 'Ülkeler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const handleCountryPress = (country) => {
    if (country.is_unlocked) {
      navigation.navigate('RecipeList', { country });
    } else {
      Alert.alert('Kilitli', 'Bu ülke henüz kilitli!');
    }
  };

  const handleLogout = async () => {
    await AsyncStorage.clear();
    navigation.navigate('Landing');
  };

  const getCountryIcon = (countryId) => {
    const icons = {
      france: '🗼',
      italy: '🍕',
      turkey: '🧿',
      japan: '🍱',
      mexico: '🌮',
    };
    return icons[countryId] || '🍽️';
  };

  return (
    <LinearGradient colors={['#E0BBE4', '#D4A5D8']} style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Seninle Mutfakta</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Social')}
          >
            <Text style={styles.headerButtonText}>Sosyal</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => navigation.navigate('Profile')}
          >
            <Text style={styles.headerButtonText}>Profil</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogout}>
            <Text style={styles.logoutText}>🚪</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.titleSection}>
          <Text style={styles.mainTitle}>Hangi Ülkeyi Keşfetmek İstersiniz?</Text>
          <Text style={styles.subtitle}>Birlikte yemek pişirme maceranıza başlayın</Text>
        </View>

        <View style={styles.countriesGrid}>
          {countries.map((country, index) => (
            <TouchableOpacity
              key={country.id}
              style={[
                styles.countryCard,
                !country.is_unlocked && styles.countryCardLocked,
              ]}
              onPress={() => handleCountryPress(country)}
            >
              <Text style={styles.countryFlag}>{country.flag}</Text>
              <Text style={styles.countryIcon}>{getCountryIcon(country.id)}</Text>
              <Text style={styles.countryName}>{country.name}</Text>
              <Text style={styles.recipeCount}>{country.recipes_count} Tarif</Text>
              {!country.is_unlocked && (
                <View style={styles.lockBadge}>
                  <Text style={styles.lockText}>🔒 Kilitli</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  headerButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  headerButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  logoutText: {
    fontSize: 24,
  },
  scrollContent: {
    padding: 20,
  },
  titleSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  mainTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#FFF',
    textAlign: 'center',
  },
  countriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 15,
  },
  countryCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    gap: 10,
  },
  countryCardLocked: {
    opacity: 0.6,
  },
  countryFlag: {
    fontSize: 50,
  },
  countryIcon: {
    fontSize: 30,
    position: 'absolute',
    top: 10,
    right: 10,
  },
  countryName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  recipeCount: {
    fontSize: 12,
    color: '#666',
  },
  lockBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  lockText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#999',
  },
});

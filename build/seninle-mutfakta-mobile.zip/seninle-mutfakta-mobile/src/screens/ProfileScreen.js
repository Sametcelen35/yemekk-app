import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import * as ImagePicker from 'expo-image-picker';
import { API_URL } from '../config/api';

export default function ProfileScreen({ navigation }) {
  const [user, setUser] = useState(null);
  const [progress, setProgress] = useState([]);
  const [completedCount, setCompletedCount] = useState(0);

  useEffect(() => {
    loadData();
    requestPermissions();
  }, []);

  const requestPermissions = async () => {
    await ImagePicker.requestMediaLibraryPermissionsAsync();
  };

  const loadData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      const token = await AsyncStorage.getItem('token');
      setUser(JSON.parse(userData));

      const progressRes = await axios.get(`${API_URL}/progress`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProgress(progressRes.data);
      const completed = progressRes.data.filter((p) => p.completed).length;
      setCompletedCount(completed);
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const getBadge = () => {
    if (completedCount >= 20) return { name: 'Usta Aşçı', icon: '👨‍🍳' };
    if (completedCount >= 10) return { name: 'Deneyimli Şef', icon: '🧑‍🍳' };
    if (completedCount >= 5) return { name: 'Mutfak Dostu', icon: '👩‍🍳' };
    return { name: 'Yeni Başlayan', icon: '🔰' };
  };

  const currentBadge = getBadge();

  const badges = [
    { id: 1, name: 'Paris Gourmet', icon: '🥐', earned: completedCount >= 3 },
    { id: 2, name: 'Pizza Master', icon: '🍕', earned: completedCount >= 5 },
    { id: 3, name: 'Sushi Samurai', icon: '🍣', earned: completedCount >= 8 },
    { id: 4, name: 'Taco Maestro', icon: '🌮', earned: completedCount >= 10 },
    { id: 5, name: 'Anadolu Chef', icon: '🧿', earned: completedCount >= 12 },
  ];

  const passports = [
    { id: 1, country: 'France', flag: '🇫🇷', earned: completedCount >= 10 },
    { id: 2, country: 'Italy', flag: '🇮🇹', earned: completedCount >= 20 },
  ];

  const handleLogout = async () => {
    Alert.alert('Çıkış', 'Çıkış yapmak istediğinize emin misiniz?', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Çıkış',
        onPress: async () => {
          await AsyncStorage.clear();
          navigation.navigate('Landing');
        },
      },
    ]);
  };

  const changeProfilePicture = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled) {
        const token = await AsyncStorage.getItem('token');
        const formData = new FormData();
        
        const filename = result.assets[0].uri.split('/').pop();
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : 'image/jpeg';
        
        formData.append('avatar', {
          uri: result.assets[0].uri,
          name: filename,
          type,
        });

        const response = await axios.post(`${API_URL}/avatars/upload`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        });

        await AsyncStorage.setItem('user', JSON.stringify(response.data));
        setUser(response.data);
        Alert.alert('Başarılı', 'Profil resminiz güncellendi!');
      }
    } catch (error) {
      Alert.alert('Hata', 'Profil resmi güncellenirken bir hata oluştu');
    }
  };

  return (
    <LinearGradient colors={['#FFE5D9', '#E0BBE4']} style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>← Anasayfa</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profilim</Text>
        <TouchableOpacity onPress={handleLogout}>
          <Text style={styles.logoutButton}>🚪</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* User Info Card */}
        <View style={styles.userCard}>
          <TouchableOpacity onPress={changeProfilePicture} style={styles.avatarContainer}>
            {user?.avatar_url ? (
              <Image source={{ uri: user.avatar_url }} style={styles.avatarImage} />
            ) : (
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{user?.name?.charAt(0).toUpperCase()}</Text>
              </View>
            )}
            <View style={styles.editBadge}>
              <Text style={styles.editIcon}>📷</Text>
            </View>
          </TouchableOpacity>
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
          <Text style={styles.userGender}>
            {user?.gender === 'female' ? '👩‍🍳 Kadın' : '👨‍🍳 Erkek'}
          </Text>
          <View style={styles.currentBadge}>
            <Text style={styles.badgeIcon}>{currentBadge.icon}</Text>
            <Text style={styles.badgeName}>{currentBadge.name}</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>👨‍🍳</Text>
            <Text style={styles.statNumber}>{completedCount}</Text>
            <Text style={styles.statLabel}>Tamamlanan</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>🏆</Text>
            <Text style={styles.statNumber}>{badges.filter((b) => b.earned).length}</Text>
            <Text style={styles.statLabel}>Rozet</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>🛂</Text>
            <Text style={styles.statNumber}>{passports.filter((p) => p.earned).length}</Text>
            <Text style={styles.statLabel}>Pasaport</Text>
          </View>
        </View>

        {/* Badges Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rozetler</Text>
          <View style={styles.badgesGrid}>
            {badges.map((badge) => (
              <View
                key={badge.id}
                style={[styles.badgeCard, !badge.earned && styles.badgeCardLocked]}
              >
                <Text style={styles.badgeCardIcon}>{badge.icon}</Text>
                <Text style={styles.badgeCardName}>{badge.name}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Passports Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Pasaportlar</Text>
          <View style={styles.passportsGrid}>
            {passports.map((passport) => (
              <View
                key={passport.id}
                style={[styles.passportCard, !passport.earned && styles.passportCardLocked]}
              >
                <Text style={styles.passportFlag}>{passport.flag}</Text>
                <Text style={styles.passportCountry}>{passport.country}</Text>
                {passport.earned && <Text style={styles.passportBadge}>✓</Text>}
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  backButton: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  logoutButton: {
    fontSize: 24,
  },
  scrollContent: {
    padding: 20,
  },
  userCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    marginBottom: 20,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 15,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFB8B8',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFF',
  },
  editBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#FFB8B8',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFF',
  },
  editIcon: {
    fontSize: 14,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  userGender: {
    fontSize: 12,
    color: '#999',
    marginBottom: 15,
  },
  currentBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(255, 184, 184, 0.2)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  badgeIcon: {
    fontSize: 24,
  },
  badgeName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  statIcon: {
    fontSize: 30,
    marginBottom: 10,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 11,
    color: '#666',
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  badgesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  badgeCard: {
    width: '30%',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    padding: 15,
    alignItems: 'center',
  },
  badgeCardLocked: {
    opacity: 0.4,
  },
  badgeCardIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  badgeCardName: {
    fontSize: 10,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  passportsGrid: {
    flexDirection: 'row',
    gap: 10,
  },
  passportCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  passportCardLocked: {
    opacity: 0.4,
  },
  passportFlag: {
    fontSize: 40,
    marginBottom: 10,
  },
  passportCountry: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  passportBadge: {
    fontSize: 20,
    color: '#4CAF50',
    marginTop: 5,
  },
});

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function LandingScreen({ navigation }) {
  return (
    <LinearGradient
      colors={['#FFE5D9', '#FFB8B8']}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Logo / Title */}
        <View style={styles.header}>
          <Text style={styles.title}>Seninle Mutfakta</Text>
          <Text style={styles.subtitle}>
            Eşinle birlikte farklı ülkelerin tariflerini keşfet ve birlikte eğlenceli anlar yaşa.
          </Text>
        </View>

        {/* Features */}
        <View style={styles.features}>
          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>👥</Text>
            <Text style={styles.featureText}>Eş Zamanlı Mod</Text>
          </View>
          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>👨‍🍳</Text>
            <Text style={styles.featureText}>50+ Tarif</Text>
          </View>
          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>🏆</Text>
            <Text style={styles.featureText}>Pasaport Rozetleri</Text>
          </View>
        </View>

        {/* Badges Preview */}
        <View style={styles.badgesSection}>
          <Text style={styles.badgesTitle}>Rozetlerini Kazan! 🏆</Text>
          <View style={styles.badgesGrid}>
            <View style={styles.badgeCard}>
              <Text style={styles.badgeIcon}>🥐</Text>
              <Text style={styles.badgeName}>Paris Gourmet</Text>
            </View>
            <View style={styles.badgeCard}>
              <Text style={styles.badgeIcon}>🍕</Text>
              <Text style={styles.badgeName}>Pizza Master</Text>
            </View>
            <View style={styles.badgeCard}>
              <Text style={styles.badgeIcon}>🍣</Text>
              <Text style={styles.badgeName}>Sushi Samurai</Text>
            </View>
            <View style={styles.badgeCard}>
              <Text style={styles.badgeIcon}>🌮</Text>
              <Text style={styles.badgeName}>Taco Maestro</Text>
            </View>
          </View>
        </View>

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.primaryButton]}
            onPress={() => navigation.navigate('Auth', { mode: 'register' })}
          >
            <Text style={styles.primaryButtonText}>Kayıt Ol</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.button, styles.secondaryButton]}
            onPress={() => navigation.navigate('Auth', { mode: 'login' })}
          >
            <Text style={styles.secondaryButtonText}>Giriş Yap</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
    alignItems: 'center',
    paddingTop: 60,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#FF6B6B',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#4A4A4A',
    textAlign: 'center',
    lineHeight: 20,
    maxWidth: 300,
  },
  features: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 15,
    marginBottom: 30,
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    width: 100,
  },
  featureIcon: {
    fontSize: 30,
    marginBottom: 5,
  },
  featureText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#4A4A4A',
    textAlign: 'center',
  },
  badgesSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  badgesTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4A4A4A',
    marginBottom: 15,
  },
  badgesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 10,
  },
  badgeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    width: 80,
  },
  badgeIcon: {
    fontSize: 28,
    marginBottom: 5,
  },
  badgeName: {
    fontSize: 9,
    fontWeight: '600',
    color: '#4A4A4A',
    textAlign: 'center',
  },
  buttonContainer: {
    width: '100%',
    gap: 10,
  },
  button: {
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 25,
    alignItems: 'center',
  },
  primaryButton: {
    backgroundColor: '#FFB8B8',
  },
  primaryButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: '#FFF',
    borderWidth: 2,
    borderColor: '#FFB8B8',
  },
  secondaryButtonText: {
    color: '#FFB8B8',
    fontSize: 16,
    fontWeight: '600',
  },
});

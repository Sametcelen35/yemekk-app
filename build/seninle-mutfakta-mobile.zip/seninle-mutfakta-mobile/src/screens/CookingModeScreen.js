import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../config/api';

export default function CookingModeScreen({ navigation, route }) {
  const { recipe } = route.params;
  const [currentStep, setCurrentStep] = useState(0);
  const [user, setUser] = useState(null);
  const [showCongrats, setShowCongrats] = useState(false);

  const defaultSteps = [
    { step_number: 1, title: 'Malzemeleri Hazırlayın', description: 'Tüm malzemeleri tezgaha dizin', animation_type: 'mix' },
    { step_number: 2, title: 'Doğrayın', description: 'Sebzeleri ince ince doğrayın', animation_type: 'chop' },
    { step_number: 3, title: 'Pişirin', description: 'Tavada orta ateşte pişirin', animation_type: 'cook' },
    { step_number: 4, title: 'Karıştırın', description: 'İçerikleri iyice karıştırın', animation_type: 'stir' },
    { step_number: 5, title: 'Servis Yapın', description: 'Tabaklara güzelce servis yapın', animation_type: 'pour' },
  ];

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const userData = await AsyncStorage.getItem('user');
    setUser(JSON.parse(userData));
  };

  const handleNext = () => {
    if (currentStep < defaultSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowCongrats(true);
    }
  };

  const handleComplete = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      await axios.post(
        `${API_URL}/progress`,
        {
          recipe_id: recipe.id,
          completed: true,
          current_step: defaultSteps.length,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      Alert.alert('Tebrikler!', 'Tarif tamamlandı! 🎉', [
        { text: 'Tamam', onPress: () => navigation.navigate('Social') },
      ]);
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Harika!', 'Tarifin tamamlandı!', [
        { text: 'Tamam', onPress: () => navigation.navigate('Dashboard') },
      ]);
    }
  };

  const getAnimationEmoji = (type) => {
    switch (type) {
      case 'chop':
        return '🔪';
      case 'stir':
        return '🥄';
      case 'cook':
        return '🍳';
      case 'mix':
        return '🥣';
      case 'pour':
        return '🍶';
      default:
        return '👨‍🍳';
    }
  };

  const currentStepData = defaultSteps[currentStep];
  const progress = ((currentStep + 1) / defaultSteps.length) * 100;

  if (showCongrats) {
    return (
      <LinearGradient colors={['#FFE5D9', '#FFB8B8']} style={styles.container}>
        <View style={styles.congratsContainer}>
          <Text style={styles.congratsEmoji}>🎉</Text>
          <Text style={styles.congratsTitle}>Harika İş Çıkardınız!</Text>
          <Text style={styles.congratsName}>{user?.name} tarifi tamamladı!</Text>
          <Text style={styles.congratsMessage}>
            Muhteşem bir yemek yaptınız! Sosyal alanda paylaşmak ister misiniz?
          </Text>
          <TouchableOpacity style={styles.completeButton} onPress={handleComplete}>
            <Text style={styles.completeButtonText}>Tarifi Tamamla</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#E0BBE4', '#FFE5D9']} style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>← Geri</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{recipe.title}</Text>
      </View>

      {/* Progress */}
      <View style={styles.progressSection}>
        <View style={styles.progressInfo}>
          <Text style={styles.progressText}>
            Adım {currentStep + 1} / {defaultSteps.length}
          </Text>
          <Text style={styles.progressPercentage}>{Math.round(progress)}%</Text>
        </View>
        <View style={styles.progressBarContainer}>
          <View style={[styles.progressBar, { width: `${progress}%` }]} />
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Step Card */}
        <View style={styles.stepCard}>
          <Text style={styles.animationEmoji}>{getAnimationEmoji(currentStepData.animation_type)}</Text>
          <Text style={styles.userEmoji}>{user?.gender === 'female' ? '👩‍🍳' : '👨‍🍳'}</Text>
          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>
        </View>

        {/* Navigation Buttons */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.navButton, currentStep === 0 && styles.navButtonDisabled]}
            onPress={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
          >
            <Text style={styles.navButtonText}>Önceki</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>
              {currentStep === defaultSteps.length - 1 ? 'Bitir ✓' : 'Sonraki →'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    gap: 15,
  },
  backButton: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  progressSection: {
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  progressInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  progressText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  progressPercentage: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFB8B8',
  },
  progressBarContainer: {
    height: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 5,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#FFB8B8',
  },
  scrollContent: {
    padding: 20,
    flexGrow: 1,
    justifyContent: 'center',
  },
  stepCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    gap: 15,
    marginBottom: 30,
  },
  animationEmoji: {
    fontSize: 40,
  },
  userEmoji: {
    fontSize: 60,
  },
  stepTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  stepDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 10,
  },
  navButton: {
    flex: 1,
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 25,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFB8B8',
  },
  navButtonDisabled: {
    opacity: 0.3,
  },
  navButtonText: {
    color: '#FFB8B8',
    fontSize: 16,
    fontWeight: '600',
  },
  nextButton: {
    flex: 2,
    backgroundColor: '#FFB8B8',
    padding: 16,
    borderRadius: 25,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  congratsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },
  congratsEmoji: {
    fontSize: 80,
    marginBottom: 20,
  },
  congratsTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  congratsName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#FFB8B8',
    marginBottom: 20,
  },
  congratsMessage: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
  },
  completeButton: {
    backgroundColor: '#FFB8B8',
    paddingVertical: 16,
    paddingHorizontal: 40,
    borderRadius: 25,
  },
  completeButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
});

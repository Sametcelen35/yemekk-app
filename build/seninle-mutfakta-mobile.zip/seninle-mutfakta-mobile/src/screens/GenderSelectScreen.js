import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../config/api';

export default function GenderSelectScreen({ navigation }) {
  const [selectedGender, setSelectedGender] = useState(null);
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!name.trim()) {
      Alert.alert('Hata', 'Lütfen adınızı girin');
      return;
    }

    setLoading(true);
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/auth/select-gender`,
        {
          gender: selectedGender,
          name: name.trim(),
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      await AsyncStorage.setItem('user', JSON.stringify(response.data));
      Alert.alert('Başarılı', 'Profil oluşturuldu!');
      navigation.navigate('Dashboard');
    } catch (error) {
      Alert.alert('Hata', 'Bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#E0BBE4', '#D4A5D8']} style={styles.container}>
      <View style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.title}>Sen Kimsin?</Text>
          <Text style={styles.subtitle}>
            Eşinle birlikte yemek pişirmeye başlamadan önce, senin rolünü seç
          </Text>

          {!selectedGender ? (
            <View style={styles.genderButtons}>
              <TouchableOpacity
                style={styles.genderButton}
                onPress={() => setSelectedGender('female')}
              >
                <Text style={styles.genderEmoji}>👩‍🍳</Text>
                <Text style={styles.genderText}>Kadınım</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.genderButton}
                onPress={() => setSelectedGender('male')}
              >
                <Text style={styles.genderEmoji}>👨‍🍳</Text>
                <Text style={styles.genderText}>Erkeğim</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.nameSection}>
              <View style={styles.selectedGender}>
                <Text style={styles.selectedEmoji}>
                  {selectedGender === 'female' ? '👩‍🍳' : '👨‍🍳'}
                </Text>
                <Text style={styles.selectedText}>
                  {selectedGender === 'female' ? 'Kadın' : 'Erkek'} profili seçildi
                </Text>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Adınız Nedir?</Text>
                <TextInput
                  style={styles.input}
                  placeholder={selectedGender === 'female' ? 'Örn: Ayşe' : 'Örn: Mehmet'}
                  value={name}
                  onChangeText={setName}
                  autoFocus
                />
              </View>

              <View style={styles.buttonRow}>
                <TouchableOpacity
                  style={[styles.button, styles.backButton]}
                  onPress={() => setSelectedGender(null)}
                >
                  <Text style={styles.backButtonText}>Geri</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.button, styles.continueButton, loading && styles.buttonDisabled]}
                  onPress={handleContinue}
                  disabled={loading}
                >
                  <Text style={styles.continueButtonText}>
                    {loading ? 'Kaydediliyor...' : 'Devam Et'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFB8B8',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
  },
  genderButtons: {
    gap: 15,
  },
  genderButton: {
    backgroundColor: '#FFB8B8',
    padding: 20,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 15,
  },
  genderEmoji: {
    fontSize: 40,
  },
  genderText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
  },
  nameSection: {
    gap: 20,
  },
  selectedGender: {
    alignItems: 'center',
    padding: 15,
  },
  selectedEmoji: {
    fontSize: 60,
    marginBottom: 10,
  },
  selectedText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 10,
  },
  button: {
    flex: 1,
    padding: 16,
    borderRadius: 25,
    alignItems: 'center',
  },
  backButton: {
    backgroundColor: '#FFF',
    borderWidth: 2,
    borderColor: '#FFB8B8',
  },
  backButtonText: {
    color: '#FFB8B8',
    fontSize: 16,
    fontWeight: '600',
  },
  continueButton: {
    backgroundColor: '#FFB8B8',
  },
  continueButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
});

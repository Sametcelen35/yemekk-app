import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../config/api';

export default function RecipeListScreen({ navigation, route }) {
  const { country } = route.params;
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRecipes();
  }, []);

  const loadRecipes = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await axios.get(`${API_URL}/recipes?country_id=${country.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      // Sort by difficulty
      const sorted = response.data.sort((a, b) => {
        const order = { easy: 1, medium: 2, hard: 3 };
        return order[a.difficulty] - order[b.difficulty];
      });
      setRecipes(sorted);
    } catch (error) {
      Alert.alert('Hata', 'Tarifler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyIcon = (difficulty) => {
    switch (difficulty) {
      case 'easy':
        return '🌶';
      case 'medium':
        return '🌶🌶';
      case 'hard':
        return '🌶🌶🌶';
      default:
        return '';
    }
  };

  const getDifficultyText = (difficulty) => {
    switch (difficulty) {
      case 'easy':
        return 'Kolay';
      case 'medium':
        return 'Orta';
      case 'hard':
        return 'Zor';
      default:
        return difficulty;
    }
  };

  return (
    <LinearGradient colors={['#FFE5D9', '#B8E6D5']} style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>← Anasayfa</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.titleSection}>
          <Text style={styles.flag}>{country.flag}</Text>
          <Text style={styles.title}>{country.name} Mutfağı</Text>
          <Text style={styles.subtitle}>Birlikte yapabileceğiniz {recipes.length} harika tarif</Text>
        </View>

        <View style={styles.recipesList}>
          {recipes.map((recipe, index) => (
            <TouchableOpacity
              key={recipe.id}
              style={styles.recipeCard}
              onPress={() => navigation.navigate('CookingMode', { recipe })}
            >
              <Image
                source={{ uri: recipe.image_url }}
                style={styles.recipeImage}
                resizeMode="cover"
              />
              <View style={styles.recipeContent}>
                <Text style={styles.recipeTitle}>{recipe.title}</Text>
                <Text style={styles.recipeDescription} numberOfLines={2}>
                  {recipe.description}
                </Text>
                <View style={styles.recipeFooter}>
                  <Text style={styles.duration}>⏱ {recipe.duration_minutes} dk</Text>
                  <View style={styles.difficultyBadge}>
                    <Text style={styles.difficultyText}>
                      {getDifficultyIcon(recipe.difficulty)} {getDifficultyText(recipe.difficulty)}
                    </Text>
                  </View>
                </View>
                <Text style={styles.stepsCount}>👨‍🍳 {recipe.steps_count} adım</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingTop: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  backButton: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  scrollContent: {
    padding: 20,
  },
  titleSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  flag: {
    fontSize: 60,
    marginBottom: 15,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
  },
  recipesList: {
    gap: 15,
  },
  recipeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  recipeImage: {
    width: '100%',
    height: 180,
  },
  recipeContent: {
    padding: 15,
    gap: 8,
  },
  recipeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  recipeDescription: {
    fontSize: 12,
    color: '#666',
  },
  recipeFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  duration: {
    fontSize: 12,
    color: '#666',
  },
  difficultyBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: '#FFE5D9',
    borderRadius: 12,
  },
  difficultyText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FF6B6B',
  },
  stepsCount: {
    fontSize: 11,
    color: '#666',
  },
});

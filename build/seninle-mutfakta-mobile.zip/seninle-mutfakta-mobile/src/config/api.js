export const API_URL = 'https://cooking-duo.preview.emergentagent.com/api';

export const endpoints = {
  auth: {
    register: '/auth/register',
    login: '/auth/login',
    selectGender: '/auth/select-gender',
    me: '/auth/me',
  },
  countries: '/countries',
  recipes: '/recipes',
  progress: '/progress',
  posts: '/posts',
  avatars: '/avatars',
};

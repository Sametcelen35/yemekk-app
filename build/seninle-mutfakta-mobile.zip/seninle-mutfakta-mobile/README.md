# 📱 Seninle Mutfakta - React Native Mobil Uygulama

## ✨ Özellikler

✅ **Tamamen Çalışır Durum**
- 7 Ekran (Landing, Auth, GenderSelect, Dashboard, RecipeList, CookingMode, Social, Profile)
- Backend entegrasyonu
- Pastel renkli modern tasarım
- Gradient arka planlar
- Yeni rozet sistemi

---

## 🚀 Kurulum

### 1. Projeyi Kur
```bash
cd seninle-mutfakta-mobile
npm install
```

### 2. Çalıştır

**Web'de Test Et (Hızlı):**
```bash
npm run web
```

**iOS Simulator (Mac gerekli):**
```bash
npm run ios
```

**Android Emulator:**
```bash
npm run android
```

**Telefonda Test Et:**
```bash
npx expo start
```
Expo Go uygulamasını indirin ve QR kodu taratın.

---

## 📦 App Store ve Play Store'a Yükleme

### EAS Build ile APK/IPA Oluştur

#### 1. EAS CLI Kur
```bash
npm install -g eas-cli
```

#### 2. Expo Hesabı Aç
```bash
eas login
```

#### 3. Build Al

**Android APK:**
```bash
eas build --platform android --profile preview
```

**iOS IPA (Mac veya EAS Build):**
```bash
eas build --platform ios --profile preview
```

**Her İkisi:**
```bash
eas build --platform all
```

10-15 dakika sonra indirme linki gelecek!

#### 4. Test Et
- Android: APK'yı telefona yükle
- iOS: TestFlight ile test et

#### 5. Store'a Yükle

**Play Store:**
- Google Play Console → Create App
- AAB dosyasını yükle (production build)
- İncelemeye gönder (1-7 gün)

**App Store:**
- App Store Connect → My Apps → New App
- IPA dosyasını yükle
- TestFlight beta test
- İncelemeye gönder (1-3 gün)

---

## 📂 Proje Yapısı

```
seninle-mutfakta-mobile/
├── App.js                          # Ana navigation
├── app.json                        # Expo config
├── src/
│   ├── config/
│   │   └── api.js                  # API endpoints
│   └── screens/
│       ├── LandingScreen.js        # Giriş sayfası
│       ├── AuthScreen.js           # Kayıt & Giriş
│       ├── GenderSelectScreen.js   # Cinsiyet + İsim
│       ├── DashboardScreen.js      # Ülkeler
│       ├── RecipeListScreen.js     # Tarifler
│       ├── CookingModeScreen.js    # Adım adım pişirme
│       ├── SocialScreen.js         # Paylaşımlar
│       └── ProfileScreen.js        # Profil & Rozetler
└── assets/                         # İkonlar & Splash
```

---

## 🎨 Tasarım

- **Renkler:** Pastel (Peach, Mint, Lavender)
- **Font:** System default (iOS: SF Pro, Android: Roboto)
- **Animasyonlar:** Smooth gradients
- **Responsive:** iOS ve Android

---

## 🔧 Backend

Backend zaten hazır ve çalışıyor:
```
https://cooking-duo.preview.emergentagent.com/api
```

Kendi backend'inizi kullanmak için:
`src/config/api.js` dosyasındaki `API_URL`'i değiştirin.

---

## 📱 Gereksinimler

- Node.js 18+
- npm veya yarn
- Expo Go app (telefon testi için)
- Xcode (iOS geliştirme için, sadece Mac)
- Android Studio (Android geliştirme için)

---

## 🐛 Sorun Giderme

### "Module not found"
```bash
rm -rf node_modules
npm install
```

### Metro bundler hatası
```bash
npx expo start --clear
```

### iOS simulator açılmıyor
```bash
sudo xcode-select --switch /Applications/Xcode.app
```

---

## 📊 Store Bilgileri

### Uygulama Açıklaması
```
Eşinizle birlikte dünya mutfaklarını keşfedin! 

"Seninle Mutfakta", çiftlerin birlikte yemek yapmasını eğlenceli bir deneyime dönüştürüyor. 

✨ Özellikler:
• 50+ farklı ülke tarifini keşfedin
• Eş zamanlı tarif takibi
• Ülke bazlı rozet ve pasaport sistemi
• Yaptığınız yemekleri sosyal alanda paylaşın
• Her adımda animasyonlu rehberlik

🌍 Ülkeler: Fransa 🇫🇷, İtalya 🇮🇹, Türkiye 🇹🇷, Japonya 🇯🇵, Meksika 🇲🇽
```

### Keywords
```
yemek, tarif, çift, mutfak, pişirme, dünya mutfağı, cooking, recipe
```

### Kategori
- Primary: Food & Drink
- Secondary: Lifestyle

---

## 🎯 Sonraki Adımlar

1. ✅ Tüm ekranlar hazır
2. ⏳ EAS Build ile APK/IPA oluştur
3. ⏳ Store'lara yükle
4. ⏳ İnceleme bekle (1-7 gün)
5. ⏳ Yayınla! 🎉

---

## 💡 İpuçları

- **Hızlı test:** `npm run web` ile tarayıcıda test edin
- **Telefonda test:** Expo Go kullanın (en hızlı)
- **Production build:** EAS Build kullanın (en kolay)
- **Icon değiştirme:** `assets/icon.png` dosyasını değiştirin (1024x1024)

---

## 📧 Destek

Sorun yaşarsanız:
1. `npx expo doctor` çalıştırın
2. Hata mesajını not edin
3. Expo documentation: https://docs.expo.dev

---

**Başarılar! 🎉**
